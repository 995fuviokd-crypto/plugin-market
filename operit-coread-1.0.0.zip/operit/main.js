const tools = require("./packages/coread_tools.js");

async function _invoke(name, params) {
    if (typeof tools[name] !== "function") return { success: false, error: "Unknown tool: " + name };
    const result = await tools[name](params || {});
    return result && result.success !== undefined ? result : { success: !!result, data: result };
}

module.exports = {
    coread_import_book: function(p) { return _invoke("coread_import_book", p); },
    coread_list_books: function(p) { return _invoke("coread_list_books", p); },
    coread_list_chapters: function(p) { return _invoke("coread_list_chapters", p); },
    coread_get_current_chapter: function(p) { return _invoke("coread_get_current_chapter", p); },
    coread_advance_chapter: function(p) { return _invoke("coread_advance_chapter", p); },
    coread_mark_highlight: function(p) { return _invoke("coread_mark_highlight", p); },
    coread_save_note: function(p) { return _invoke("coread_save_note", p); },
    coread_get_highlights: function(p) { return _invoke("coread_get_highlights", p); },
    coread_export_markdown: function(p) { return _invoke("coread_export_markdown", p); },
    coread_delete_book: function(p) { return _invoke("coread_delete_book", p); },
};