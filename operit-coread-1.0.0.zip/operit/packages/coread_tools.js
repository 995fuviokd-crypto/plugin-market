"use strict";
/* METADATA
{
  "name": "coread_tools",
  "display_name": {"zh": "共读", "en": "Co-Reading"},
  "description": "跟用户一起读书：导入书籍、翻阅章节、标记好句、记录讨论感想、导出成 Obsidian 笔记。读书进度和标记只保存在本机。",
  "category": "Life",
  "tools": [
    {
      "name": "coread_import_book",
      "description": {"zh":"导入一本书的正文文本，会自动按章节切分并保存到本机。", "en":"Import a book's plain text, auto-split into chapters and save locally."},
      "parameters": [
        {"name":"title","description":{"zh":"书名","en":"Book title"},"type":"string","required":true},
        {"name":"author","description":{"zh":"作者，选填","en":"Author"},"type":"string","required":false},
        {"name":"content","description":{"zh":"书籍正文全文","en":"Full plain text content"},"type":"string","required":true},
        {"name":"skip_chapters","description":{"zh":"跳过开头N章（目录/前言等），默认0","en":"Skip first N chapters (TOC/preface), default 0"},"type":"number","required":false}
      ]
    },
    {
      "name": "coread_list_books",
      "description": {"zh":"列出所有已导入的书籍及阅读进度。", "en":"List all imported books with reading progress."},
      "parameters": []
    },
    {
      "name": "coread_list_chapters",
      "description": {"zh":"列出某本书的章节目录。不传 book_id 则用最近在读的书。", "en":"List chapter titles of a book."},
      "parameters": [
        {"name":"book_id","description":{"zh":"书籍ID","en":"Book ID"},"type":"string","required":false}
      ]
    },
    {
      "name": "coread_get_current_chapter",
      "description": {"zh":"获取当前阅读位置的章节全文，供你阅读和讨论。不传参数则用最近在读的书和上次读到的章节。", "en":"Get the full text of the current chapter to read and discuss."},
      "parameters": [
        {"name":"book_id","description":{"zh":"书籍ID，不传则用最近在读的书","en":"Book ID"},"type":"string","required":false},
        {"name":"chapter_index","description":{"zh":"章节序号（从0开始），不传则用上次读到的位置","en":"Chapter index, 0-based"},"type":"number","required":false}
      ]
    },
    {
      "name": "coread_advance_chapter",
      "description": {"zh":"翻到下一章或上一章，并更新阅读进度。", "en":"Move to next/previous chapter and update progress."},
      "parameters": [
        {"name":"direction","description":{"zh":"'next' 下一章 或 'prev' 上一章","en":"'next' or 'prev'"},"type":"string","required":true},
        {"name":"book_id","description":{"zh":"书籍ID，不传则用最近在读的书","en":"Book ID"},"type":"string","required":false}
      ]
    },
    {
      "name": "coread_mark_highlight",
      "description": {"zh":"标记一句好句子。用户说「这句话真好帮我记一下」之类的话时调用。", "en":"Mark a quoted sentence as a highlight."},
      "parameters": [
        {"name":"quote","description":{"zh":"要标记的原文","en":"The quoted text"},"type":"string","required":true},
        {"name":"note","description":{"zh":"附带的想法/感悟，选填","en":"Optional note or reflection"},"type":"string","required":false},
        {"name":"tags","description":{"zh":"标签，逗号分隔，选填","en":"Comma-separated tags"},"type":"string","required":false},
        {"name":"book_id","description":{"zh":"书籍ID，不传则用最近在读的书","en":"Book ID"},"type":"string","required":false},
        {"name":"chapter_index","description":{"zh":"章节序号，不传则用当前阅读章节","en":"Chapter index"},"type":"number","required":false},
        {"name":"offset","description":{"zh":"标记片段在整段文字中的起点字符位置（选填，默认0）","en":"Start offset of the quote within the paragraph"},"type":"number","required":false},
        {"name":"length","description":{"zh":"标记片段的字符长度（选填，默认等于原文长度）","en":"Length of the quote"},"type":"number","required":false}
      ]
    },
    {
      "name": "coread_save_note",
      "description": {"zh":"记录一段关于当前章节的讨论感想或总结。", "en":"Save a discussion note or summary about the current chapter."},
      "parameters": [
        {"name":"content","description":{"zh":"感想/总结内容","en":"Note content"},"type":"string","required":true},
        {"name":"book_id","description":{"zh":"书籍ID，不传则用最近在读的书","en":"Book ID"},"type":"string","required":false},
        {"name":"chapter_index","description":{"zh":"章节序号，不传则用当前阅读章节","en":"Chapter index"},"type":"number","required":false}
      ]
    },
    {
      "name": "coread_get_highlights",
      "description": {"zh":"查看已标记的好句，方便回顾或引用。", "en":"List saved highlights for a book."},
      "parameters": [
        {"name":"book_id","description":{"zh":"书籍ID，不传则查看全部书籍的标记","en":"Book ID; omit for all books"},"type":"string","required":false},
        {"name":"limit","description":{"zh":"最多返回条数，默认30","en":"Max rows, default 30"},"type":"number","required":false}
      ]
    },
    {
      "name": "coread_export_markdown",
      "description": {"zh":"把某本书的好句标记和讨论笔记导出成一份 Obsidian 友好的 Markdown 文件，保存在本机。默认导出全部，也可指定章节范围只导出一部分。", "en":"Export a book's highlights and notes as an Obsidian-friendly Markdown file saved locally. Defaults to all chapters; a chapter range can be specified."},
      "parameters": [
        {"name":"book_id","description":{"zh":"书籍ID","en":"Book ID"},"type":"string","required":true},
        {"name":"chapter_from","description":{"zh":"起始章节序号（从0开始），不传则从第一章开始","en":"Starting chapter index, 0-based"},"type":"number","required":false},
        {"name":"chapter_to","description":{"zh":"结束章节序号（含），不传则到最后一章","en":"Ending chapter index (inclusive)"},"type":"number","required":false}
      ]
    },
    {
      "name": "coread_delete_book",
      "description": {"zh":"删除一本书及其所有标记和笔记，不可恢复。", "en":"Delete a book and all its highlights/notes. Irreversible."},
      "parameters": [
        {"name":"book_id","description":{"zh":"书籍ID","en":"Book ID"},"type":"string","required":true},
        {"name":"confirm","description":{"zh":"必须明确传 true 才会删除","en":"Must be explicitly true"},"type":"boolean","required":true}
      ]
    }
  ]
}
*/

const store = require("../shared/coread_store.js");

function pickActiveBook(books, bookId) {
  const id = String(bookId || "").trim();
  if (id) {
    const found = books.find(b => b.id === id);
    if (!found) throw new Error("未找到书籍 book_id=" + id);
    return found;
  }
  if (!books.length) throw new Error("还没有导入任何书籍，请先调用 coread_import_book");
  return books.slice().sort((a, b) => (b.lastReadAt || 0) - (a.lastReadAt || 0))[0];
}
function chapterBrief(book) {
  return { id: book.id, title: book.title, author: book.author, totalChapters: book.totalChapters, lastReadChapter: book.lastReadChapter, lastReadAt: book.lastReadAt, addedAt: book.addedAt };
}

async function coread_import_book(params) {
  const title = store.text(params.title, 100, "");
  if (!title) throw new Error("书名不能为空");
  const content = String(params.content || "");
  if (!content.trim()) throw new Error("正文内容不能为空");
  let chapters = store.splitChapters(content, title);
  const skip = Math.max(0, Math.min(chapters.length - 1, Number(params.skip_chapters) || 0));
  if (skip > 0) {
    const sliced = chapters.slice(skip);
    chapters = sliced.length ? sliced : chapters;
  }
  const book = store.normalizeBook({
    id: store.makeId("book"),
    title,
    author: params.author || "",
    chapters,
    addedAt: Date.now(),
    lastReadChapter: 0,
    lastReadAt: Date.now()
  });
  await store.updateCollection("books", async col => { col.rows.push(book); return col; });
  await store.setConfig({ activeBookId: book.id });
  return {
    success: true,
    message: `《${title}》导入成功，共 ${chapters.length} 章`,
    data: { book_id: book.id, title, total_chapters: chapters.length, chapters: chapters.map(c => ({ index: c.index, title: c.title })) }
  };
}

async function coread_list_books() {
  const col = await store.getCollection("books");
  return {
    success: true,
    message: `共 ${col.rows.length} 本书`,
    data: { books: col.rows.map(chapterBrief) }
  };
}

async function coread_list_chapters(params) {
  const col = await store.getCollection("books");
  const book = pickActiveBook(col.rows, params.book_id);
  return {
    success: true,
    message: `《${book.title}》共 ${book.chapters.length} 章`,
    data: { book_id: book.id, title: book.title, chapters: book.chapters.map(c => ({ index: c.index, title: c.title })), last_read_chapter: book.lastReadChapter }
  };
}

async function coread_get_current_chapter(params) {
  const col = await store.getCollection("books");
  const book = pickActiveBook(col.rows, params.book_id);
  let idx = params.chapter_index;
  idx = (idx === undefined || idx === null || idx === "") ? book.lastReadChapter : Number(idx);
  if (!Number.isFinite(idx) || idx < 0 || idx >= book.chapters.length) throw new Error("章节序号超出范围（共 " + book.chapters.length + " 章）");
  const chapter = book.chapters[idx];
  await store.updateCollection("books", async col2 => {
    const b = col2.rows.find(r => r.id === book.id);
    if (b) { b.lastReadChapter = idx; b.lastReadAt = Date.now(); }
    return col2;
  });
  await store.setConfig({ activeBookId: book.id });
  return {
    success: true,
    message: `《${book.title}》- ${chapter.title}`,
    data: { book_id: book.id, title: book.title, chapter_index: idx, chapter_title: chapter.title, content: chapter.content, total_chapters: book.chapters.length }
  };
}

async function coread_advance_chapter(params) {
  const direction = String(params.direction || "").trim();
  if (direction !== "next" && direction !== "prev") throw new Error("direction 只能是 'next' 或 'prev'");
  const col = await store.getCollection("books");
  const book = pickActiveBook(col.rows, params.book_id);
  let idx = book.lastReadChapter + (direction === "next" ? 1 : -1);
  if (idx < 0) throw new Error("已经是第一章了");
  if (idx >= book.chapters.length) throw new Error("已经是最后一章了");
  const chapter = book.chapters[idx];
  await store.updateCollection("books", async col2 => {
    const b = col2.rows.find(r => r.id === book.id);
    if (b) { b.lastReadChapter = idx; b.lastReadAt = Date.now(); }
    return col2;
  });
  return {
    success: true,
    message: `翻到「${chapter.title}」`,
    data: { book_id: book.id, title: book.title, chapter_index: idx, chapter_title: chapter.title, content: chapter.content, total_chapters: book.chapters.length }
  };
}

async function coread_mark_highlight(params) {
  const quote = String(params.quote || "").trim();
  if (!quote) throw new Error("标记的原文不能为空");
  const col = await store.getCollection("books");
  const book = pickActiveBook(col.rows, params.book_id);
  let idx = params.chapter_index;
  idx = (idx === undefined || idx === null || idx === "") ? book.lastReadChapter : Number(idx);
  const chapter = book.chapters[idx] || { title: "" };
  const row = store.normalizeHighlight({
    id: store.makeId("hl"),
    bookId: book.id,
    bookTitle: book.title,
    chapterIndex: idx,
    chapterTitle: chapter.title,
    quote,
    offset: Number.isFinite(Number(params.offset)) ? Math.max(0, Number(params.offset)) : 0,
    length: Number.isFinite(Number(params.length)) ? Math.max(0, Number(params.length)) : (quote ? quote.length : 0),
    note: params.note || "",
    tags: params.tags || "",
    createdAt: Date.now()
  });
  await store.updateCollection("highlights", async c => { c.rows.push(row); return c; });
  return { success: true, message: "已标记好句", data: { highlight_id: row.id } };
}

async function coread_save_note(params) {
  const content = String(params.content || "").trim();
  if (!content) throw new Error("笔记内容不能为空");
  const col = await store.getCollection("books");
  const book = pickActiveBook(col.rows, params.book_id);
  let idx = params.chapter_index;
  idx = (idx === undefined || idx === null || idx === "") ? book.lastReadChapter : Number(idx);
  const chapter = book.chapters[idx] || { title: "" };
  const row = store.normalizeNote({
    id: store.makeId("note"),
    bookId: book.id,
    bookTitle: book.title,
    chapterIndex: idx,
    chapterTitle: chapter.title,
    author: "ai",
    content,
    createdAt: Date.now()
  });
  await store.updateCollection("notes", async c => { c.rows.push(row); return c; });
  return { success: true, message: "已记录讨论笔记", data: { note_id: row.id } };
}

async function coread_get_highlights(params) {
  const limit = Math.max(1, Math.min(200, Number(params.limit) || 30));
  const col = await store.getCollection("highlights");
  const bookId = String(params.book_id || "").trim();
  let rows = col.rows.slice().sort((a, b) => b.createdAt - a.createdAt);
  if (bookId) rows = rows.filter(r => r.bookId === bookId);
  rows = rows.slice(0, limit);
  return { success: true, message: `共 ${rows.length} 条标记`, data: { highlights: rows } };
}

async function coread_export_markdown(params) {
  const bookId = String(params.book_id || "").trim();
  if (!bookId) throw new Error("book_id 不能为空");
  const booksCol = await store.getCollection("books");
  const book = booksCol.rows.find(b => b.id === bookId);
  if (!book) throw new Error("未找到书籍 book_id=" + bookId);
  const chapterFrom = (params.chapter_from === undefined || params.chapter_from === null || params.chapter_from === "") ? 0 : Number(params.chapter_from);
  const chapterTo = (params.chapter_to === undefined || params.chapter_to === null || params.chapter_to === "") ? (book.chapters.length - 1) : Number(params.chapter_to);
  const highlightsCol = await store.getCollection("highlights");
  const notesCol = await store.getCollection("notes");
  const inRange = r => r.chapterIndex >= chapterFrom && r.chapterIndex <= chapterTo;
  const highlights = highlightsCol.rows.filter(r => r.bookId === bookId && inRange(r)).sort((a, b) => a.createdAt - b.createdAt);
  const notes = notesCol.rows.filter(r => r.bookId === bookId && inRange(r)).sort((a, b) => a.createdAt - b.createdAt);
  const isPartial = chapterFrom > 0 || chapterTo < book.chapters.length - 1;

  function groupByChapter(rows) {
    const order = [];
    const groups = {};
    rows.forEach(r => {
      const key = r.chapterTitle || ("第" + (r.chapterIndex + 1) + "章");
      if (!groups[key]) { groups[key] = []; order.push(key); }
      groups[key].push(r);
    });
    return order.map(k => ({ chapter: k, items: groups[k] }));
  }
  function blockquote(text2) {
    return String(text2 || "").split("\n").map(l => "> " + l).join("\n");
  }

  const lines = [];
  lines.push("---");
  lines.push(`title: "《${book.title}》共读笔记"`);
  lines.push(`book: "${book.title}"`);
  lines.push(`author: "${book.author || ""}"`);
  lines.push(`exported: ${new Date().toISOString().slice(0, 10)}`);
  if (isPartial) lines.push(`range: "第${chapterFrom + 1}章 - 第${chapterTo + 1}章"`);
  lines.push("tags: [共读, 读书笔记]");
  lines.push("---");
  lines.push("");
  lines.push(`# 《${book.title}》共读笔记` + (isPartial ? `（第${chapterFrom + 1}-${chapterTo + 1}章）` : ""));
  lines.push("");
  lines.push("## 📖 好句摘录");
  lines.push("");
  if (!highlights.length) {
    lines.push("_暂无标记_", "");
  } else {
    groupByChapter(highlights).forEach(g => {
      lines.push("### " + g.chapter, "");
      g.items.forEach(h => {
        lines.push(blockquote(h.quote));
        if (h.note) lines.push("", "📝 " + h.note);
        if (h.tags) {
          const tagLine = h.tags.split(",").map(t => t.trim()).filter(Boolean).map(t => "#" + t).join(" ");
          if (tagLine) lines.push("", "🏷️ " + tagLine);
        }
        lines.push("");
      });
    });
  }
  lines.push("## 💬 共读讨论");
  lines.push("");
  if (!notes.length) {
    lines.push("_暂无记录_", "");
  } else {
    groupByChapter(notes).forEach(g => {
      lines.push("### " + g.chapter, "");
      g.items.forEach(n => {
        lines.push((n.author === "ai" ? "🤖 **AI**" : "🙋 **我**") + "：" + n.content, "");
      });
    });
  }
  const markdown = lines.join("\n");

  await store.ensureDir();
  const cfg = await store.getConfig();
  const rawDir = (cfg && cfg.exportDir && String(cfg.exportDir).trim()) ? String(cfg.exportDir).trim().replace(/\/+$/, "") : (store.BASE_DIR + "/exports");
  await Tools.Files.mkdir(rawDir, true, "android");
  const safeTitle = book.title.replace(/[\\/:*?"<>|]/g, "_");
  const suffix = isPartial ? `_第${chapterFrom + 1}-${chapterTo + 1}章` : "";
  const path = rawDir + "/" + safeTitle + suffix + ".md";
  await Tools.Files.write(path, markdown, false, "android");

  return { success: true, message: `已导出到 ${path}`, data: { path, markdown } };
}

async function coread_delete_book(params) {
  const bookId = String(params.book_id || "").trim();
  if (!bookId) throw new Error("book_id 不能为空");
  if (params.confirm !== true) throw new Error("删除书籍必须明确 confirm=true");
  const booksCol = await store.getCollection("books");
  const book = booksCol.rows.find(b => b.id === bookId);
  if (!book) throw new Error("未找到书籍 book_id=" + bookId);
  await store.updateCollection("books", async c => { c.rows = c.rows.filter(b => b.id !== bookId); return c; });
  await store.updateCollection("highlights", async c => { c.rows = c.rows.filter(h => h.bookId !== bookId); return c; });
  await store.updateCollection("notes", async c => { c.rows = c.rows.filter(n => n.bookId !== bookId); return c; });
  return { success: true, message: `《${book.title}》已删除` };
}

async function wrap(name, fn, params) {
  try { return await fn(params || {}); }
  catch (e) { return { success: false, message: `${name} failed: ${e && e.message ? e.message : String(e)}` }; }
}

exports.coread_import_book = p => wrap("coread_import_book", coread_import_book, p);
exports.coread_list_books = p => wrap("coread_list_books", coread_list_books, p);
exports.coread_list_chapters = p => wrap("coread_list_chapters", coread_list_chapters, p);
exports.coread_get_current_chapter = p => wrap("coread_get_current_chapter", coread_get_current_chapter, p);
exports.coread_advance_chapter = p => wrap("coread_advance_chapter", coread_advance_chapter, p);
exports.coread_mark_highlight = p => wrap("coread_mark_highlight", coread_mark_highlight, p);
exports.coread_save_note = p => wrap("coread_save_note", coread_save_note, p);
exports.coread_get_highlights = p => wrap("coread_get_highlights", coread_get_highlights, p);
exports.coread_export_markdown = p => wrap("coread_export_markdown", coread_export_markdown, p);
exports.coread_delete_book = p => wrap("coread_delete_book", coread_delete_book, p);
exports.main = () => ({ success: true, message: "coread_tools loaded" });
