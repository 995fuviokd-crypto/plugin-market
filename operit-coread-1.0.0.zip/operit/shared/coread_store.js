"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

const BASE_DIR = "data";
const FILES = {
  config: BASE_DIR + "/config.json",
  books: BASE_DIR + "/books.json",
  highlights: BASE_DIR + "/highlights.json",
  notes: BASE_DIR + "/notes.json"
};

const DEFAULT_CONFIG = {
  schemaVersion: 1,
  theme: "cream",
  customPrimaryHex: "#c17a3f",
  customIsDark: false,
  fontSizeId: "m",
  activeBookId: "",
  companionCharacterCard: "",
  companionChatId: "",
  exportDir: BASE_DIR + "/exports"
};
const EMPTY_COLLECTION = { schemaVersion: 1, updatedAt: 0, rows: [] };
const THEME_VALUES = ["cream", "mist", "forest", "night", "ink", "custom"];
const FONT_SIZE_VALUES = ["s", "m", "l", "xl"];

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function text(value, max, fallback) {
  const out = String(value == null ? "" : value).trim();
  return (out || fallback || "").slice(0, max);
}
function normalizeTheme(value) {
  const raw = String(value == null ? "" : value).trim();
  return THEME_VALUES.includes(raw) ? raw : "cream";
}
function normalizeFontSizeId(value) {
  const raw = String(value == null ? "" : value).trim();
  return FONT_SIZE_VALUES.includes(raw) ? raw : "m";
}
function normalizeConfig(raw) {
  const value = { ...clone(DEFAULT_CONFIG), ...(raw || {}) };
  value.schemaVersion = 1;
  value.theme = normalizeTheme(value.theme);
  value.fontSizeId = normalizeFontSizeId(value.fontSizeId);
  value.customPrimaryHex = /^#?[0-9a-fA-F]{6}$/.test(String(value.customPrimaryHex || "").trim()) ? value.customPrimaryHex.trim() : "#c17a3f";
  value.customIsDark = value.customIsDark === true;
  value.activeBookId = text(value.activeBookId, 64, "");
  value.companionCharacterCard = text(value.companionCharacterCard, 120, "");
  value.companionChatId = text(value.companionChatId, 120, "");
  value.exportDir = text(value.exportDir, 200, BASE_DIR + "/exports");
  return value;
}
function normalizeChapter(raw, index) {
  raw = raw || {};
  return {
    index: Number.isFinite(Number(raw.index)) ? Number(raw.index) : index,
    title: text(raw.title, 80, "第" + (index + 1) + "章"),
    content: String(raw.content == null ? "" : raw.content)
  };
}
function normalizeBook(raw) {
  raw = raw || {};
  const chapters = Array.isArray(raw.chapters) ? raw.chapters.map((c, i) => normalizeChapter(c, i)) : [];
  return {
    id: text(raw.id, 64, ""),
    title: text(raw.title, 100, "未命名书籍"),
    author: text(raw.author, 60, ""),
    chapters,
    totalChapters: chapters.length,
    lastReadChapter: Math.max(0, Math.min(chapters.length - 1, Number.isFinite(Number(raw.lastReadChapter)) ? Number(raw.lastReadChapter) : 0)),
    lastReadPage: Math.max(0, Number.isFinite(Number(raw.lastReadPage)) ? Number(raw.lastReadPage) : 0),
    addedAt: Number.isFinite(Number(raw.addedAt)) ? Number(raw.addedAt) : Date.now(),
    lastReadAt: Number.isFinite(Number(raw.lastReadAt)) ? Number(raw.lastReadAt) : 0
  };
}
function normalizeHighlight(raw) {
  raw = raw || {};
  const q = String(raw.quote == null ? "" : raw.quote);
  return {
    id: text(raw.id, 64, ""),
    bookId: text(raw.bookId, 64, ""),
    bookTitle: text(raw.bookTitle, 100, ""),
    chapterIndex: Number.isFinite(Number(raw.chapterIndex)) ? Number(raw.chapterIndex) : 0,
    chapterTitle: text(raw.chapterTitle, 80, ""),
    quote: q.slice(0, 2000),
    // 标记片段在整段内的起点与长度；旧数据无此字段时 offset=0、length=quote 长度，均兼容
    offset: Number.isFinite(Number(raw.offset)) ? Math.max(0, Number(raw.offset)) : 0,
    length: Number.isFinite(Number(raw.length)) ? Math.max(0, Number(raw.length)) : q.length,
    note: text(raw.note, 500, ""),
    tags: text(raw.tags, 200, ""),
    createdAt: Number.isFinite(Number(raw.createdAt)) ? Number(raw.createdAt) : Date.now()
  };
}
function normalizeNote(raw) {
  raw = raw || {};
  return {
    id: text(raw.id, 64, ""),
    bookId: text(raw.bookId, 64, ""),
    bookTitle: text(raw.bookTitle, 100, ""),
    chapterIndex: Number.isFinite(Number(raw.chapterIndex)) ? Number(raw.chapterIndex) : 0,
    chapterTitle: text(raw.chapterTitle, 80, ""),
    author: raw.author === "ai" ? "ai" : "user",
    content: String(raw.content == null ? "" : raw.content).slice(0, 4000),
    createdAt: Number.isFinite(Number(raw.createdAt)) ? Number(raw.createdAt) : Date.now()
  };
}
function normalizeCollection(name) {
  return function (raw) {
    const rows = Array.isArray(raw && raw.rows) ? raw.rows : [];
    const normalizer = name === "books" ? normalizeBook : (name === "highlights" ? normalizeHighlight : normalizeNote);
    return {
      schemaVersion: 1,
      updatedAt: Math.max(0, Number(raw && raw.updatedAt) || 0),
      rows: rows.map(normalizer)
    };
  };
}

async function ensureDir() {
  if (typeof Tools === "undefined" || !Tools.Files) throw new Error("文件工具不可用");
  await Tools.Files.mkdir(BASE_DIR);
  await Tools.Files.mkdir(BASE_DIR + "/exports");
}
async function exists(path) {
  const result = await Tools.Files.exists(path, "android");
  return !!(result && result.exists);
}
async function readText(path) {
  const result = await Tools.Files.read(path);
  return result && typeof result.content === "string" ? result.content : "";
}
async function readJson(path, fallback, normalizer) {
  await ensureDir();
  try {
    if (!(await exists(path))) return normalizer(clone(fallback));
    return normalizer(JSON.parse(await readText(path)));
  } catch (_) {
    const backupPath = path + ".bak";
    try {
      if (await exists(backupPath)) return normalizer(JSON.parse(await readText(backupPath)));
    } catch (_) {}
    return normalizer(clone(fallback));
  }
}
async function safeWriteJson(path, value, normalizer) {
  await ensureDir();
  const normalized = normalizer(value);
  const payload = JSON.stringify(normalized, null, 2);
  JSON.parse(payload);
  if (await exists(path)) {
    try {
      const current = await readText(path);
      JSON.parse(current);
      await Tools.Files.write(path + ".bak", current, false, "android");
    } catch (_) {}
  }
  const tempPath = path + ".tmp";
  await Tools.Files.write(tempPath, payload, false, "android");
  const verified = normalizer(JSON.parse(await readText(tempPath)));
  await Tools.Files.write(path, JSON.stringify(verified, null, 2), false, "android");
  return verified;
}

async function getConfig() { return readJson(FILES.config, DEFAULT_CONFIG, normalizeConfig); }
async function setConfig(patch) {
  const current = await getConfig();
  return safeWriteJson(FILES.config, { ...current, ...(patch || {}) }, normalizeConfig);
}
async function getCollection(name) {
  if (!Object.prototype.hasOwnProperty.call(FILES, name) || name === "config") throw new Error("未知数据集合");
  return readJson(FILES[name], EMPTY_COLLECTION, normalizeCollection(name));
}
async function setCollection(name, value) {
  if (!Object.prototype.hasOwnProperty.call(FILES, name) || name === "config") throw new Error("未知数据集合");
  const next = normalizeCollection(name)(value);
  next.updatedAt = Date.now();
  return safeWriteJson(FILES[name], next, normalizeCollection(name));
}
async function updateCollection(name, updater) {
  const current = await getCollection(name);
  const next = await updater(clone(current));
  return setCollection(name, next || current);
}
function makeId(prefix) {
  return String(prefix || "row") + "_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 9);
}

async function setReadPosition(bookId, chapterIndex, pageIndex) {
  await updateCollection("books", async col => {
    const b = col.rows.find(r => r.id === bookId);
    if (b) { b.lastReadChapter = chapterIndex; b.lastReadPage = Math.max(0, pageIndex | 0); b.lastReadAt = Date.now(); }
    return col;
  });
}

// ===== 章节切分 =====
const CHAPTER_PATTERNS = [
  /^第[0-9一二三四五六七八九十百千万零〇]+[章节回卷部篇集][\s:：、.．]*.*$/,
  /^(序章|楔子|引子|序言|前言|尾声|终章|后记|番外|终局|结局)[\s:：、.．]*.*$/,
  /^chapter\s+\S+/i,
  /^[0-9]{1,4}[.、][\s]*\S+/
];
function splitChapters(rawText, bookTitle) {
  // 统一换行符：兼容 \r\n（Windows）、单独 \r（老式 Mac）、\n（Unix）三种情况，
  // 否则单独 \r 的文本会被当成一整行，导致完全识别不出章节标题
  const normalized = String(rawText || "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = normalized.split("\n");
  const marks = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line || line.length > 40) continue;
    if (CHAPTER_PATTERNS.some(p => p.test(line))) marks.push({ line: i, title: line });
  }
  if (marks.length === 0) {
    return [{ index: 0, title: bookTitle || "全文", content: normalized.trim() }];
  }
  const raw = [];
  for (let i = 0; i < marks.length; i++) {
    const start = marks[i].line;
    const end = i + 1 < marks.length ? marks[i + 1].line : lines.length;
    const body = lines.slice(start + 1, end).join("\n").trim();
    raw.push({ title: marks[i].title, content: body });
  }
  // 目录里的「第X章 XXX」会被逐行识别成独立章节，但它们之间往往没有正文，
  // 正文为空（trim 后为 0）的章节直接丢弃，避免导入后目录占满一堆空章、要翻很久才到正文
  const chapters = raw.filter(c => c.content.length > 0);
  if (chapters.length === 0) {
    // 整本只有目录（全是空章），退回成整本一章，防止整本书被识别丢
    return [{ index: 0, title: bookTitle || "全文", content: normalized.trim() }];
  }
  // 第一个章节标题之前如果还有内容（比如书名页、简介），单独存成"引言"章节，避免丢失
  if (marks[0].line > 0) {
    const preface = lines.slice(0, marks[0].line).join("\n").trim();
    if (preface) chapters.unshift({ title: "引言", content: preface });
  }
  chapters.forEach((c, idx) => { c.index = idx; });
  return chapters;
}

exports.BASE_DIR = BASE_DIR;
exports.FILES = FILES;
exports.DEFAULT_CONFIG = DEFAULT_CONFIG;
exports.THEME_VALUES = THEME_VALUES;
exports.normalizeTheme = normalizeTheme;
exports.normalizeConfig = normalizeConfig;
exports.normalizeBook = normalizeBook;
exports.normalizeHighlight = normalizeHighlight;
exports.normalizeNote = normalizeNote;
exports.ensureDir = ensureDir;
exports.getConfig = getConfig;
exports.setConfig = setConfig;
exports.getCollection = getCollection;
exports.setCollection = setCollection;
exports.updateCollection = updateCollection;
exports.makeId = makeId;
exports.setReadPosition = setReadPosition;
exports.text = text;
exports.splitChapters = splitChapters;
