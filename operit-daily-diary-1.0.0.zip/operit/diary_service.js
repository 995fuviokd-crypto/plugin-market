"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStorageDir = getStorageDir;
exports.getStoragePath = getStoragePath;
exports.ensureStorage = ensureStorage;
exports.loadData = loadData;
exports.saveData = saveData;
exports.listEntries = listEntries;
exports.getEntry = getEntry;
exports.createEntry = createEntry;
exports.updateEntry = updateEntry;
exports.deleteEntry = deleteEntry;
exports.addComment = addComment;
exports.getSettings = getSettings;
exports.updateSettings = updateSettings;
exports.getConfig = getConfig;
exports.updateConfig = updateConfig;
exports.deleteComment = deleteComment;

const DATA_DIR_NAME = "daily_diary";
const DATA_FILE_NAME = "diary_entries.json";

function getStorageRoot() {
    return "";
}

function getStorageDir() {
    return getStorageRoot() + "/" + DATA_DIR_NAME;
}

function getStoragePath() {
    return getStorageDir() + "/" + DATA_FILE_NAME;
}

async function callFileApi(name, args) {
    if (typeof Tools !== "undefined" && Tools && Tools.Files && typeof Tools.Files[name] === "function") {
        return await Tools.Files[name].apply(Tools.Files, args || []);
    }
    throw new Error("Tools.Files." + name + " is not available");
}

async function fileExists(path) {
    const result = await callFileApi("exists", [path]);
    return !!(result && result.exists);
}

async function readFile(path) {
    const result = await callFileApi("read", [path]);
    return String((result && result.content) || "");
}

async function writeFile(path, content) {
    return await callFileApi("write", [path, content, false]);
}

async function mkdir(path) {
    return await callFileApi("mkdir", [path, true]);
}

function normalizeData(data) {
    if (!data || typeof data !== "object") {
        return { diaryName: "我的日记本", entries: [] };
    }
    if (!Array.isArray(data.entries)) data.entries = [];
    if (!data.diaryName) data.diaryName = "我的日记本";
    data.entries = data.entries.map(function(e) {
        if (!e.comments || !Array.isArray(e.comments)) e.comments = [];
        return e;
    });
    return data;
}

async function ensureStorage() {
    const dir = getStorageDir();
    const path = getStoragePath();
    await mkdir(dir);
    const exists = await fileExists(path);
    if (!exists) {
        await writeFile(path, JSON.stringify({ diaryName: "我的日记本", entries: [] }, null, 2));
    }
}

async function loadData() {
    await ensureStorage();
    try {
        const content = await readFile(getStoragePath());
        const parsed = content.trim() ? JSON.parse(content) : { diaryName: "我的日记本", entries: [] };
        return normalizeData(parsed);
    } catch (_) {
        return { diaryName: "我的日记本", entries: [] };
    }
}

async function saveData(data) {
    await ensureStorage();
    const normalized = normalizeData(data);
    await writeFile(getStoragePath(), JSON.stringify(normalized, null, 2));
    return true;
}

function genId() {
    const chars = "0123456789abcdefghijklmnopqrstuvwxyz";
    let id = "";
    for (let i = 0; i < 12; i++) id += chars[Math.floor(Math.random() * chars.length)];
    return Date.now().toString(36) + id;
}

async function listEntries(date) {
    const data = await loadData();
    let entries = data.entries || [];
    if (date) entries = entries.filter(function(e) { return e.date === date; });
    entries = [].concat(entries).sort(function(a, b) {
        if (a.date !== b.date) return String(b.date || "").localeCompare(String(a.date || ""));
        return String(b.createdAt || "").localeCompare(String(a.createdAt || ""));
    });
    return entries.map(function(e) {
        return {
            id: e.id,
            date: e.date || "",
            title: e.title || "",
            content: e.content || "",
            mood: e.mood || "",
            commentCount: (e.comments || []).length,
            updatedAt: e.updatedAt || ""
        };
    });
}

async function getEntry(id) {
    const data = await loadData();
    for (let i = 0; i < data.entries.length; i++) {
        if (data.entries[i].id === id) return data.entries[i];
    }
    return null;
}

async function createEntry(title, content, date, mood) {
    const data = await loadData();
    const now = new Date().toISOString();
    const today = now.substring(0, 10);
    const entry = {
        id: genId(),
        title: title || "",
        content: content || "",
        date: date || today,
        mood: mood || "",
        createdAt: now,
        updatedAt: now,
        comments: []
    };
    data.entries.push(entry);
    await saveData(data);
    return entry;
}

async function updateEntry(id, fields) {
    const data = await loadData();
    const idx = data.entries.findIndex(function(e) { return e.id === id; });
    if (idx === -1) return null;
    const entry = data.entries[idx];
    if (fields.title !== undefined) entry.title = fields.title;
    if (fields.content !== undefined) entry.content = fields.content;
    if (fields.date !== undefined) entry.date = fields.date;
    if (fields.mood !== undefined) entry.mood = fields.mood;
    entry.updatedAt = new Date().toISOString();
    data.entries[idx] = entry;
    await saveData(data);
    return entry;
}

async function deleteEntry(id) {
    const data = await loadData();
    const idx = data.entries.findIndex(function(e) { return e.id === id; });
    if (idx === -1) return false;
    data.entries.splice(idx, 1);
    await saveData(data);
    return true;
}

async function addComment(entryId, author, content, color) {
    const data = await loadData();
    const entry = data.entries.find(function(e) { return e.id === entryId; });
    if (!entry) return null;
    if (!Array.isArray(entry.comments)) entry.comments = [];
    const comment = {
        id: genId(),
        author: author || "用户",
        content: content || "",
        timestamp: new Date().toISOString()
    };
    if (color) comment.color = color;
    entry.comments.push(comment);
    entry.updatedAt = new Date().toISOString();
    await saveData(data);
    return comment;
}

async function getSettings() {
    const data = await loadData();
    return { diaryName: data.diaryName || "我的日记本" };
}

async function updateSettings(fields) {
    const data = await loadData();
    if (fields && fields.diaryName !== undefined) data.diaryName = fields.diaryName;
    await saveData(data);
    return true;
}

// ===== 插件配置 =====
const CONFIG_FILE = "config.json";
const DEFAULT_CONFIG = {
    defaultAvatar: "",
    aiName: "Skon",
    aiAvatar: "",
    userName: "用户"
};

function getConfigDir() {
    try {
        if (typeof ToolPkg !== "undefined" && ToolPkg && typeof ToolPkg.getConfigDir === "function") {
            return ToolPkg.getConfigDir();
        }
    } catch (_) {}
    return getStorageDir();
}

function getConfigPath() {
    return getConfigDir() + "/" + CONFIG_FILE;
}

async function ensureConfig() {
    await mkdir(getConfigDir());
    const exists = await fileExists(getConfigPath());
    if (!exists) {
        await writeFile(getConfigPath(), JSON.stringify(DEFAULT_CONFIG, null, 2));
    }
}

async function getConfig() {
    await ensureConfig();
    try {
        const content = await readFile(getConfigPath());
        const parsed = content.trim() ? JSON.parse(content) : {};
        return {
            defaultAvatar: parsed.defaultAvatar || DEFAULT_CONFIG.defaultAvatar,
            aiName: parsed.aiName || DEFAULT_CONFIG.aiName,
            aiAvatar: parsed.aiAvatar || DEFAULT_CONFIG.aiAvatar,
            userName: parsed.userName || DEFAULT_CONFIG.userName
        };
    } catch (_) {
        return { ...DEFAULT_CONFIG };
    }
}

async function updateConfig(fields) {
    await ensureConfig();
    const current = await getConfig();
    if (fields && fields.defaultAvatar !== undefined) current.defaultAvatar = fields.defaultAvatar;
    if (fields && fields.aiName !== undefined) current.aiName = fields.aiName;
    if (fields && fields.aiAvatar !== undefined) current.aiAvatar = fields.aiAvatar;
    if (fields && fields.userName !== undefined) current.userName = fields.userName;
    await writeFile(getConfigPath(), JSON.stringify(current, null, 2));
    return current;
}

async function deleteComment(entryId, commentId) {
    const data = await loadData();
    const entry = data.entries.find(function(e) { return e.id === entryId; });
    if (!entry || !Array.isArray(entry.comments)) return false;
    var idx = entry.comments.findIndex(function(c) { return c.id === commentId; });
    if (idx === -1) return false;
    entry.comments.splice(idx, 1);
    entry.updatedAt = new Date().toISOString();
    await saveData(data);
    return true;
}
