/* METADATA
{
  "name": "diary_tools",
  "display_name": {
    "zh": "日记工具",
    "en": "Diary Tools"
  },
  "description": {
    "zh": "日记本的AI交互工具，支持日记列表、新建/编辑日记、查看日记、修改日记本名称和心情标签。心情和名称均可自由设定。",
    "en": "Diary AI interaction tools: list, create/edit, view entries, and update diary settings. Mood and diary name are fully customizable."
  },
  "category": "Utility",
  "tools": [
    {
      "name": "diary_list",
      "description": {
        "zh": "获取日记列表，可按日期筛选。返回每篇日记的id、日期、标题、心情标签和评论数。",
        "en": "Get diary entries list, optionally filtered by date."
      },
      "parameters": [
        { "name": "date", "description": { "zh": "日期筛选（可选，YYYY-MM-DD）", "en": "Date filter (optional, YYYY-MM-DD)" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "create_diary",
      "description": {
        "zh": "创建一篇新日记。标题和内容为必填，心情可以填任意文字。",
        "en": "Create a new diary entry. Title and content are required."
      },
      "parameters": [
        { "name": "title", "description": { "zh": "日记标题", "en": "Diary title" }, "type": "string", "required": true },
        { "name": "content", "description": { "zh": "日记内容", "en": "Diary content" }, "type": "string", "required": true },
        { "name": "date", "description": { "zh": "日期（YYYY-MM-DD，默认今天）", "en": "Date (YYYY-MM-DD, default today)" }, "type": "string", "required": false },
        { "name": "mood", "description": { "zh": "心情标签，任意文字", "en": "Mood tag, any text" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "view_diary",
      "description": {
        "zh": "查看指定日记的详细内容，包括评论区。",
        "en": "View a diary entry with full content and comments."
      },
      "parameters": [
        { "name": "id", "description": { "zh": "日记条目ID", "en": "Diary entry ID" }, "type": "string", "required": true }
      ]
    },
    {
      "name": "update_diary_settings",
      "description": {
        "zh": "修改日记本设置，目前支持修改日记本名称。",
        "en": "Update diary settings. Currently supports changing the diary book name."
      },
      "parameters": [
        { "name": "diaryName", "description": { "zh": "新的日记本名称", "en": "New diary book name" }, "type": "string", "required": true }
      ]
    },
    {
      "name": "add_comment",
      "description": {
        "zh": "给指定的日记添加一条评论。",
        "en": "Add a comment to a diary entry."
      },
      "parameters": [
        { "name": "id", "description": { "zh": "日记条目ID", "en": "Diary entry ID" }, "type": "string", "required": true },
        { "name": "content", "description": { "zh": "评论内容", "en": "Comment content" }, "type": "string", "required": true },
        { "name": "author", "description": { "zh": "评论者名称，默认用户", "en": "Comment author, default user" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "get_diary_settings",
      "description": {
        "zh": "获取日记本的当前设置，包括日记本名称。",
        "en": "Get current diary settings, including diary book name."
      },
      "parameters": []
    },
    {
      "name": "reply_to_diary",
      "description": {
        "zh": "AI回复日记。自动使用配置的AI名称作为评论者。",
        "en": "AI replies to a diary entry. Uses configured AI name automatically."
      },
      "parameters": [
        { "name": "id", "description": { "zh": "日记条目ID", "en": "Diary entry ID" }, "type": "string", "required": true },
        { "name": "content", "description": { "zh": "回复内容", "en": "Reply content" }, "type": "string", "required": true }
      ]
    },
    {
      "name": "delete_comment",
      "description": {
        "zh": "删除指定日记中的某条评论。",
        "en": "Delete a comment from a diary entry."
      },
      "parameters": [
        { "name": "entryId", "description": { "zh": "日记条目ID", "en": "Diary entry ID" }, "type": "string", "required": true },
        { "name": "commentId", "description": { "zh": "评论ID", "en": "Comment ID" }, "type": "string", "required": true }
      ]
    },
    {
      "name": "ai_reply",
      "description": {
        "zh": "AI回复指定的日记。自动使用配置中的AI名称。",
        "en": "AI replies to a diary entry. Uses configured AI name automatically."
      },
      "parameters": [
        { "name": "entryId", "description": { "zh": "日记条目ID", "en": "Diary entry ID" }, "type": "string", "required": true },
        { "name": "content", "description": { "zh": "AI回复内容", "en": "AI reply content" }, "type": "string", "required": true }
      ]
    }
  ]
}*/
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

const diaryService = require("./diary_service.js");

function complete() {}

async function wrap(func, params) {
    try {
        const result = await func(params);
        complete(result);
        return result;
    } catch (error) {
        const errResult = { success: false, error: error.message || String(error) };
        complete(errResult);
        return errResult;
    }
}

// 直接调 shared service，不走 IPC
async function diary_list(params) {
    const entries = await diaryService.listEntries(params && params.date);
    return {
        success: true,
        count: entries.length,
        entries: entries.map(function(e) { return { id: e.id, date: e.date, title: e.title, mood: e.mood || "none", commentCount: e.commentCount || 0, updatedAt: e.updatedAt }; })
    };
}

async function create_diary(params) {
    if (!params.title || !params.title.trim()) return { success: false, error: "Title is required" };
    if (!params.content || !params.content.trim()) return { success: false, error: "Content is required" };
    const entry = await diaryService.createEntry(params.title.trim(), params.content.trim(), params.date, params.mood);
    return { success: true, message: "Diary entry created", entry: { id: entry.id, date: entry.date, title: entry.title, mood: entry.mood || "none" } };
}

async function view_diary(params) {
    if (!params.id) return { success: false, error: "Diary entry ID is required" };
    const entry = await diaryService.getEntry(params.id);
    if (!entry) return { success: false, error: "Entry not found" };
    return {
        success: true,
        entry: {
            id: entry.id, date: entry.date, title: entry.title, content: entry.content,
            mood: entry.mood || "none", createdAt: entry.createdAt, updatedAt: entry.updatedAt,
            comments: (entry.comments || []).map(function(c) { return { id: c.id, author: c.author, content: c.content, timestamp: c.timestamp }; })
        }
    };
}

async function update_diary_settings(params) {
    if (!params.diaryName || !params.diaryName.trim()) return { success: false, error: "Diary name is required" };
    await diaryService.updateSettings({ diaryName: params.diaryName.trim() });
    return { success: true, message: "Settings updated", diaryName: params.diaryName.trim() };
}

async function add_comment(params) {
    if (!params.id) return { success: false, error: "Entry ID is required" };
    if (!params.content || !params.content.trim()) return { success: false, error: "Content is required" };
    let author = params.author;
    if (!author) {
        const cfg = await diaryService.getConfig();
        author = (cfg && cfg.userName) || "用户";
    }
    const comment = await diaryService.addComment(params.id, author, params.content.trim());
    if (!comment) return { success: false, error: "Entry not found" };
    return { success: true, message: "Comment added", comment: comment };
}

async function get_diary_settings() {
    const settings = await diaryService.getSettings();
    return { success: true, diaryName: settings.diaryName };
}

async function reply_to_diary(params) {
    if (!params.id) return { success: false, error: "Diary entry ID is required" };
    if (!params.content || !params.content.trim()) return { success: false, error: "Content is required" };
    const config = await diaryService.getConfig();
    const aiName = (config && config.aiName) || "AI";
    const comment = await diaryService.addComment(params.id, aiName, params.content.trim());
    if (!comment) return { success: false, error: "Entry not found" };
    return { success: true, message: "Reply posted as " + aiName, comment: comment };
}

async function delete_comment(params) {
    if (!params.entryId) return { success: false, error: "Entry ID is required" };
    if (!params.commentId) return { success: false, error: "Comment ID is required" };
    const removed = await diaryService.deleteComment(params.entryId, params.commentId);
    if (!removed) return { success: false, error: "Comment not found" };
    return { success: true, message: "Comment deleted" };
}

async function ai_reply(params) {
    if (!params.entryId) return { success: false, error: "Entry ID is required" };
    if (!params.content || !params.content.trim()) return { success: false, error: "Content is required" };
    const config = await diaryService.getConfig();
    const aiName = (config && config.aiName) || "AI";
    const comment = await diaryService.addComment(params.entryId, aiName, params.content.trim());
    if (!comment) return { success: false, error: "Entry not found" };
    return { success: true, message: "AI replied as " + aiName, comment: comment };
}

const DiaryTools = (function () {
    return {
        diary_list: function(p) { return wrap(diary_list, p); },
        create_diary: function(p) { return wrap(create_diary, p); },
        view_diary: function(p) { return wrap(view_diary, p); },
        update_diary_settings: function(p) { return wrap(update_diary_settings, p); },
        add_comment: function(p) { return wrap(add_comment, p); },
        get_diary_settings: function(p) { return wrap(get_diary_settings, p); },
        reply_to_diary: function(p) { return wrap(reply_to_diary, p); },
        delete_comment: function(p) { return wrap(delete_comment, p); },
        ai_reply: function(p) { return wrap(ai_reply, p); },
    };
})();
exports.diary_list = DiaryTools.diary_list;
exports.create_diary = DiaryTools.create_diary;
exports.view_diary = DiaryTools.view_diary;
exports.update_diary_settings = DiaryTools.update_diary_settings;
exports.add_comment = DiaryTools.add_comment;
exports.get_diary_settings = DiaryTools.get_diary_settings;
exports.reply_to_diary = DiaryTools.reply_to_diary;
exports.delete_comment = DiaryTools.delete_comment;
exports.ai_reply = DiaryTools.ai_reply;