const tools = require("./diary_tools.js");

async function _invoke(name, params) {
    if (typeof tools[name] !== "function") return { success: false, error: "Unknown tool: " + name };
    const result = await tools[name](params || {});
    return result && result.success !== undefined ? result : { success: !!result, data: result };
}

module.exports = {
    diary_list: function(p) { return _invoke("diary_list", p); },
    create_diary: function(p) { return _invoke("create_diary", p); },
    view_diary: function(p) { return _invoke("view_diary", p); },
    update_diary_settings: function(p) { return _invoke("update_diary_settings", p); },
    add_comment: function(p) { return _invoke("add_comment", p); },
    get_diary_settings: function(p) { return _invoke("get_diary_settings", p); },
    reply_to_diary: function(p) { return _invoke("reply_to_diary", p); },
    delete_comment: function(p) { return _invoke("delete_comment", p); },
    ai_reply: function(p) { return _invoke("ai_reply", p); },
};
