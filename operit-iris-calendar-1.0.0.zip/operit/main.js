const tools = require("./iris_calendar.js");

async function _invoke(name, params) {
    if (typeof tools[name] !== "function") return { success: false, error: "Unknown tool: " + name };
    const result = await tools[name](params || {});
    return result && result.success !== undefined ? result : { success: !!result, data: result };
}

module.exports = {
    record_mood: function(p) { return _invoke("record_mood", p); },
    record_period: function(p) { return _invoke("record_period", p); },
    record_period_detail: function(p) { return _invoke("record_period_detail", p); },
    record_sick: function(p) { return _invoke("record_sick", p); },
    record_schedule: function(p) { return _invoke("record_schedule", p); },
    set_anniversary: function(p) { return _invoke("set_anniversary", p); },
    record_course: function(p) { return _invoke("record_course", p); },
    update_semester_start: function(p) { return _invoke("update_semester_start", p); },
    get_calendar_data: function(p) { return _invoke("get_calendar_data", p); },
    get_mood_summary: function(p) { return _invoke("get_mood_summary", p); },
    get_schedules: function(p) { return _invoke("get_schedules", p); },
    get_courses: function(p) { return _invoke("get_courses", p); },
    update_period_settings: function(p) { return _invoke("update_period_settings", p); },
    get_anniversaries: function(p) { return _invoke("get_anniversaries", p); },
    delete_mood: function(p) { return _invoke("delete_mood", p); },
    delete_period: function(p) { return _invoke("delete_period", p); },
    delete_period_detail: function(p) { return _invoke("delete_period_detail", p); },
    delete_sick: function(p) { return _invoke("delete_sick", p); },
    delete_schedule: function(p) { return _invoke("delete_schedule", p); },
    delete_anniversary: function(p) { return _invoke("delete_anniversary", p); },
    delete_course: function(p) { return _invoke("delete_course", p); },
};
