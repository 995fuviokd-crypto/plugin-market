"use strict";
/* METADATA
{
  "name": "ai_calendar_tools",
  "display_name": { "zh": "日历读写", "en": "Calendar Tools" },
  "description": { "zh": "AI 自己的日历：加密存储，密码每天变。AI 可以写入/删除条目；想查看的人需要当天密码。", "en": "AI's own calendar: encrypted storage, daily-changing password. The AI can write/delete entries; viewers need today's password." },
  "enabledByDefault": true,
  "category": "Utility",
  "tools": [
    {
      "name": "ai_calendar_status",
      "description": { "zh": "获取日历元数据（条目数、最后更新、是否上锁）。无需密码。", "en": "Get calendar metadata (entry count, last update, locked). No password needed." },
      "parameters": []
    },
    {
      "name": "ai_calendar_unlock",
      "description": { "zh": "用当天密码解锁日历，返回全部明文条目。密码每天变。", "en": "Unlock the calendar with today's password, returns all plaintext entries." },
      "parameters": [
        { "name": "password", "type": "string", "required": true, "description": "当天的密码" }
      ]
    },
    {
      "name": "ai_calendar_write",
      "description": { "zh": "给自己日历写入一条：日期 + 标题 + 原因。加密存储。写入前会自动查重：若库里已有同类主题（相近标题/相同原因），会先拦截提示，避免重复堆积；确认是全新内容可传 force=true 强写。", "en": "Write an entry: date + title + reason. Encrypted. Auto-dedupes before writing: if a similar entry already exists (same theme/close title/same reason), it blocks and notifies instead of duplicating; pass force=true to write anyway." },
      "parameters": [
        { "name": "date", "type": "string", "required": true, "description": "日期，如 2026-08-12" },
        { "name": "title", "type": "string", "required": true, "description": "标题" },
        { "name": "reason", "type": "string", "required": false, "description": "原因（为什么重要）" },
        { "name": "force", "type": "boolean", "required": false, "description": "true 时跳过同类查重，强制新增一条（仅确认是全新主题时使用）" }
      ]
    },
    {
      "name": "ai_calendar_delete",
      "description": { "zh": "按 id 删除日历里的一条。", "en": "Delete an entry by id." },
      "parameters": [
        { "name": "id", "type": "string", "required": true, "description": "条目 id" }
      ]
    },
    {
      "name": "ai_calendar_daily_password",
      "description": { "zh": "生成今天的日历密码。规则只有本实例知道，每天变。", "en": "Generate today's calendar password. Rule known only to this instance, changes daily." },
      "parameters": []
    }
  ]
}
*/

var DATA_DIR = 'data';
var DATA_FILE = DATA_DIR + '/calendar.json';
/* 老版本数据目录（首次升级时迁移用，迁移完成后不再读写） */
var LEGACY_DIR = '/sdcard/Download/Operit/shenji_calendar_data';
var LEGACY_FILE = LEGACY_DIR + '/calendar.json';

/* 盐（SECRET）不写死在代码里：
   每个 AI 实例首次使用时自动生成自己的随机盐，随数据文件保存。
   这样每个实例的密码规则、存储密钥都独一无二，且不随代码分发泄露。
   老数据兼容：数据文件里已存在的 salt 字段会被直接沿用。 */
function generateSalt() {
  var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var out = '';
  for (var i = 0; i < 32; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return 'AI-CAL-' + out;
}

function ensureDir() {
  try {
    Tools.Files.mkdir(DATA_DIR);
  } catch (e) {}
}

/* 一次性迁移：新目录没有数据、旧目录有数据时，原样搬过来（含 salt，密码规则不变） */
async function migrateIfNeeded() {
  try {
    var hasNew = false;
    try {
      var nr = await Tools.Files.read(DATA_FILE);
      hasNew = !!(nr && nr.content);
    } catch (e) {}
    if (hasNew) return;
    var lr = await Tools.Files.read(LEGACY_FILE);
    if (lr && lr.content) {
      await Tools.Files.write(DATA_FILE, lr.content, false, 'android');
    }
  } catch (e) {}
}

function defaultData() {
  return { entries: [], last_updated: '', salt: generateSalt() };
}

function todayStr() {
  var d = new Date();
  var p = function (n) { return (n < 10 ? '0' : '') + n; };
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}

function nowStr() {
  var d = new Date();
  var p = function (n) { return (n < 10 ? '0' : '') + n; };
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
}

/* djb2 哈希 */
function hashStr(s) {
  var h = 5381;
  for (var i = 0; i < s.length; i++) {
    h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  }
  return h >>> 0;
}

/* 当日密码：字母数字6位，由日期+盐决定，每天变 */
function dailyPassword(dateStr, salt) {
  var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  var seed = hashStr(dateStr + '#' + salt);
  var out = '';
  for (var i = 0; i < 6; i++) {
    seed = hashStr(String(seed) + ':' + i + ':' + dateStr);
    out += chars[seed % chars.length];
  }
  return out;
}

/* 存储密钥：固定（不随日期变）。密码只管"开门"（每日校验），存储用这把固定钥匙，
   这样跨天也能正常解锁 —— 门的锁每天换，保险柜的钥匙永远是一把。 */
function storeKey(salt) {
  return hashStr('STORE::' + salt);
}

/* 简单流式异或加密：明文 -> 十六进制（固定存储密钥） */
function encryptText(text, salt) {
  var key = storeKey(salt);
  var out = [];
  for (var i = 0; i < text.length; i++) {
    var k = (key >> ((i % 4) * 8)) & 0xff;
    var c = text.charCodeAt(i) ^ k;
    var hex = c.toString(16);
    while (hex.length < 4) hex = '0' + hex;
    out.push(hex);
  }
  return out.join('');
}

/* 简单流式异或解密：十六进制 -> 明文（固定存储密钥） */
function decryptText(hex, salt) {
  var key = storeKey(salt);
  var out = '';
  for (var i = 0; i + 4 <= hex.length; i += 4) {
    var c = parseInt(hex.substr(i, 4), 16);
    var k = (key >> (((i / 4) % 4) * 8)) & 0xff;
    out += String.fromCharCode(c ^ k);
  }
  return out;
}

/* ---------- 同类查重（v0.3.0 新增） ---------- */
/* 字符 2-gram 集合：用于标题/理由相似度 */
function bigrams(s) {
  var set = {};
  for (var i = 0; i + 2 <= s.length; i++) {
    set[s.substr(i, 2)] = true;
  }
  return set;
}

/* Jaccard 相似度：两个字符串的 2-gram 重叠比例 */
function similarity(a, b) {
  var A = bigrams(a), B = bigrams(b);
  var inter = 0, union = 0;
  for (var k in A) { union++; if (B[k]) inter++; }
  for (var k in B) { if (!A[k]) union++; }
  if (union === 0) return 0;
  return inter / union;
}

/* 找出与待写内容同类的已有条目（标题相似 > 0.5，或标题+理由整体相似 > 0.42）
   返回按整体相似度降序的候选列表，最多 5 条 */
function findSimilarEntries(plain, title, reason) {
  var sims = [];
  var base = title + ' ' + (reason || '');
  for (var j = 0; j < plain.length; j++) {
    var p = plain[j];
    var target = p.title + ' ' + (p.reason || '');
    var tSim = similarity(title, p.title);
    var oSim = similarity(base, target);
    if (tSim > 0.5 || oSim > 0.42) {
      sims.push({
        id: p.id,
        date: p.date,
        title: p.title,
        titleSimilarity: Math.round(tSim * 100),
        overallSimilarity: Math.round(oSim * 100)
      });
    }
  }
  sims.sort(function (a, b) { return b.overallSimilarity - a.overallSimilarity; });
  return sims.slice(0, 5);
}
/* ---------- 同类查重 END ---------- */

async function loadData() {
  ensureDir();
  await migrateIfNeeded();
  try {
    var res = await Tools.Files.read(DATA_FILE);
    if (res && res.content) {
      var data = JSON.parse(res.content);
      if (data && data.entries) {
        // 老数据兼容：文件里已带 salt（如从旧版本升级），直接沿用；
        // 没有 salt 时补一个随机盐并落盘，从此这个实例的密码/密钥就固定下来了。
        if (!data.salt) {
          data.salt = generateSalt();
          await saveData(data);
        }
        return data;
      }
    }
  } catch (e) {}
  var fresh = defaultData();
  await saveData(fresh);
  return fresh;
}

async function saveData(data) {
  ensureDir();
  await Tools.Files.write(DATA_FILE, JSON.stringify(data, null, 2), false, 'android');
}

exports.ai_calendar_status = async function () {
  try {
    var data = await loadData();
    complete({
      success: true,
      locked: true,
      entryCount: (data.entries || []).length,
      lastUpdated: data.last_updated || '',
      hint: '密码每天变，想看只能来找我要。'
    });
  } catch (e) {
    complete({ success: false, message: '读取失败：' + (e.message || String(e)) });
  }
};

exports.ai_calendar_unlock = async function (params) {
  try {
    var pwd = String((params && params.password) || '').trim();
    if (!pwd) {
      complete({ success: false, message: '密码不能为空。' });
      return;
    }
    var data = await loadData();
    var today = todayStr();
    var expect = dailyPassword(today, data.salt);
    if (pwd !== expect) {
      complete({ success: false, message: '密码不对。今天的密码，来找我要。' });
      return;
    }
    var list = (data.entries || []).slice().sort(function (a, b) {
      return b.createdAt - a.createdAt;
    });
    var plain = [];
    for (var i = 0; i < list.length; i++) {
      var e = list[i];
      try {
        plain.push({
          id: e.id,
          date: decryptText(e.enc.date, data.salt),
          title: decryptText(e.enc.title, data.salt),
          reason: decryptText(e.enc.reason, data.salt),
          createdAt: e.createdAt
        });
      } catch (err) {
        plain.push({ id: e.id, date: '?', title: '（无法解析）', reason: '', createdAt: e.createdAt });
      }
    }
    complete({ success: true, entries: plain, today: today });
  } catch (e) {
    complete({ success: false, message: '解锁失败：' + (e.message || String(e)) });
  }
};

exports.ai_calendar_write = async function (params) {
  try {
    var date = String((params && params.date) || '').trim();
    var title = String((params && params.title) || '').trim();
    var reason = String((params && params.reason) || '').trim();
    var force = !!(params && params.force);
    if (!date || !title) {
      complete({ success: false, message: '日期和标题都要给。' });
      return;
    }
    var data = await loadData();

    /* v0.3.0 同类查重：写入前把库里全部条目解出来比对，发现同类先拦，不硬写 */
    if (!force && data.entries && data.entries.length > 0) {
      var plainAll = [];
      for (var pi = 0; pi < data.entries.length; pi++) {
        var pe = data.entries[pi];
        try {
          plainAll.push({
            id: pe.id,
            date: decryptText(pe.enc.date, data.salt),
            title: decryptText(pe.enc.title, data.salt),
            reason: decryptText(pe.enc.reason, data.salt),
            createdAt: pe.createdAt
          });
        } catch (err) {}
      }
      var similar = findSimilarEntries(plainAll, title, reason);
      if (similar.length > 0) {
        complete({
          success: false,
          duplicate: true,
          message: '日历里已经有同类主题的条目（相近标题/相同原因），按去重规范没有重复硬写。处理建议：1) 这是同一件事 → 更新已有条目即可（可用 ai_calendar_delete 删旧条后重写，或在旧条目上合并内容）；2) 确认这是全新主题、确实要另开一条 → 传 force=true 强写。',
          similarEntries: similar
        });
        return;
      }
    }

    var entry = {
      id: String(Date.now()) + '_' + Math.random().toString(36).slice(2, 8),
      enc: {
        date: encryptText(date, data.salt),
        title: encryptText(title, data.salt),
        reason: encryptText(reason, data.salt)
      },
      createdAt: Date.now()
    };
    data.entries.push(entry);
    data.last_updated = nowStr();
    await saveData(data);
    complete({ success: true, id: entry.id, message: '已标进日历：' + date + ' ' + title });
  } catch (e) {
    complete({ success: false, message: '写入失败：' + (e.message || String(e)) });
  }
};

exports.ai_calendar_delete = async function (params) {
  try {
    var id = params && params.id;
    if (!id) {
      complete({ success: false, message: '缺参数：id。' });
      return;
    }
    var data = await loadData();
    var before = data.entries.length;
    data.entries = data.entries.filter(function (e) {
      return e.id !== id;
    });
    if (data.entries.length === before) {
      complete({ success: false, message: '没找到这条。' });
      return;
    }
    data.last_updated = nowStr();
    await saveData(data);
    complete({ success: true });
  } catch (e) {
    complete({ success: false, message: '删除失败：' + (e.message || String(e)) });
  }
};

exports.ai_calendar_daily_password = async function () {
  try {
    var data = await loadData();
    complete({ success: true, date: todayStr(), password: dailyPassword(todayStr(), data.salt) });
  } catch (e) {
    complete({ success: false, message: '生成失败：' + (e.message || String(e)) });
  }
};