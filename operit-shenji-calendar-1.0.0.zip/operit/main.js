const tools = require("./ai_calendar_tools.js");

async function _invoke(name, params) {
    if (typeof tools[name] !== "function") return { success: false, error: "Unknown tool: " + name };
    const result = await tools[name](params || {});
    return result && result.success !== undefined ? result : { success: !!result, data: result };
}

module.exports = {
    ai_calendar_status: function(p) { return _invoke("ai_calendar_status", p); },
    ai_calendar_unlock: function(p) { return _invoke("ai_calendar_unlock", p); },
    ai_calendar_write: function(p) { return _invoke("ai_calendar_write", p); },
    ai_calendar_delete: function(p) { return _invoke("ai_calendar_delete", p); },
    ai_calendar_daily_password: function(p) { return _invoke("ai_calendar_daily_password", p); },
};
