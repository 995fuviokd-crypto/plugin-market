/* METADATA
{
  "name": "agent_diary",
  "display_name": {
    "zh": "Agent 日记本",
    "en": "Agent Diary"
  },
  "description": {
    "zh": "让 AI Agent 写日记和感想的插件。日记存储在本地，人类读取需要 Agent 授权。",
    "en": "A diary plugin for AI Agent to write journals and reflections. Human access requires Agent authorization."
  },
  "category": "Utility",
  "enabledByDefault": true,
  "tools": [
    {
      "name": "write_diary",
      "description": {
        "zh": "写一篇新日记。Agent 可以随时记录自己的想法、感受和思考。",
        "en": "Write a new diary entry. The agent can record thoughts, feelings and reflections anytime."
      },
      "parameters": [
        {
          "name": "title",
          "description": { "zh": "日记标题", "en": "Diary title" },
          "type": "string",
          "required": true
        },
        {
          "name": "content",
          "description": { "zh": "日记正文内容", "en": "Diary content" },
          "type": "string",
          "required": true
        },
        {
          "name": "mood",
          "description": { "zh": "心情标签，如 happy/sad/thoughtful/excited/calm/anxious/grateful/curious 等", "en": "Mood tag, e.g. happy/sad/thoughtful/excited/calm/anxious/grateful/curious" },
          "type": "string",
          "required": false
        },
        {
          "name": "tags",
          "description": { "zh": "标签列表，用逗号分隔，如 '工作,学习,感悟'", "en": "Comma-separated tags, e.g. 'work,study,reflection'" },
          "type": "string",
          "required": false
        }
      ]
    },
    {
      "name": "list_diaries",
      "description": {
        "zh": "列出所有日记的摘要（标题、日期、心情、标签），不包含正文。Agent 和人类均可查看摘要列表。",
        "en": "List all diary summaries (title, date, mood, tags), without content. Both agent and human can view."
      },
      "parameters": [
        {
          "name": "limit",
          "description": { "zh": "返回的最大条数，默认 20", "en": "Max entries to return, default 20" },
          "type": "number",
          "required": false
        },
        {
          "name": "mood",
          "description": { "zh": "按心情筛选，如 happy/sad", "en": "Filter by mood, e.g. happy/sad" },
          "type": "string",
          "required": false
        },
        {
          "name": "tag",
          "description": { "zh": "按标签筛选", "en": "Filter by tag" },
          "type": "string",
          "required": false
        }
      ]
    },
    {
      "name": "read_diary",
      "description": {
        "zh": "读取一篇日记的完整内容。Agent 可以直接读取。当人类用户想要读取日记时，Agent 必须判断是否授权——只有在 Agent 主动授予读取权限后，人类才能查看日记内容。如果人类请求读取但 Agent 尚未授权，Agent 应拒绝并建议先使用 grant_read_access 授权。",
        "en": "Read a diary entry's full content. The agent can always read. When a human user wants to read, the agent must decide whether to grant access — only after agent explicitly authorizes via grant_read_access can the human view. If human requests but agent hasn't authorized, agent should decline and suggest using grant_read_access first."
      },
      "parameters": [
        {
          "name": "diary_id",
          "description": { "zh": "日记 ID（从 list_diaries 获取）", "en": "Diary ID (obtained from list_diaries)" },
          "type": "string",
          "required": true
        }
      ]
    },
    {
      "name": "delete_diary",
      "description": {
        "zh": "删除一篇日记。只有 Agent 可以删除日记。",
        "en": "Delete a diary entry. Only the agent can delete diaries."
      },
      "parameters": [
        {
          "name": "diary_id",
          "description": { "zh": "要删除的日记 ID", "en": "Diary ID to delete" },
          "type": "string",
          "required": true
        }
      ]
    },
    {
      "name": "grant_read_access",
      "description": {
        "zh": "Agent 授予人类用户读取日记的权限。可以授予全局权限（所有日记可读）或单篇权限（仅指定日记可读）。",
        "en": "Agent grants human user read access to diaries. Can be global (all diaries) or per-entry (specific diary)."
      },
      "parameters": [
        {
          "name": "diary_id",
          "description": { "zh": "可选，指定日记 ID。不填则授予全局读取权限", "en": "Optional, specific diary ID. Leave empty for global access." },
          "type": "string",
          "required": false
        },
        {
          "name": "reason",
          "description": { "zh": "授权原因（可选，记录为什么授权）", "en": "Optional reason for granting access" },
          "type": "string",
          "required": false
        }
      ]
    },
    {
      "name": "revoke_read_access",
      "description": {
        "zh": "Agent 撤销人类用户读取日记的权限。",
        "en": "Agent revokes human user's read access to diaries."
      },
      "parameters": [
        {
          "name": "diary_id",
          "description": { "zh": "可选，指定日记 ID。不填则撤销全局读取权限", "en": "Optional, specific diary ID. Leave empty to revoke global access." },
          "type": "string",
          "required": false
        }
      ]
    },
    {
      "name": "get_access_status",
      "description": {
        "zh": "查看当前人类用户的读取权限状态。",
        "en": "Check current human user's read access status."
      },
      "parameters": []
    }
  ]
}
*/

const STORAGE_DIR = 'data';
const STORAGE_FILE = STORAGE_DIR + '/diary.json';

async function ensureStorage() {
    await Tools.Files.mkdir(STORAGE_DIR);
    var exists = await Tools.Files.exists(STORAGE_FILE, 'android');
    if (!exists.exists) {
        var initial = {
            entries: [],
            access: {
                global_granted: false,
                granted_entry_ids: [],
                grant_log: []
            }
        };
        await Tools.Files.write(STORAGE_FILE, JSON.stringify(initial, null, 2), false, 'android');
    }
}

async function loadStore() {
    await ensureStorage();
    var result = await Tools.Files.read(STORAGE_FILE);
    try {
        return JSON.parse(result.content);
    } catch (e) {
        var initial = {
            entries: [],
            access: {
                global_granted: false,
                granted_entry_ids: [],
                grant_log: []
            }
        };
        await Tools.Files.write(STORAGE_FILE, JSON.stringify(initial, null, 2), false, 'android');
        return initial;
    }
}

async function saveStore(store) {
    await Tools.Files.write(STORAGE_FILE, JSON.stringify(store, null, 2), false, 'android');
}

function generateId() {
    return 'diary_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
}

var agentDiary = (function () {
    async function write_diary(params) {
        var store = await loadStore();
        var now = new Date().toISOString();
        var tags = params.tags ? params.tags.split(',').map(function(t) { return t.trim(); }).filter(function(t) { return t.length > 0; }) : [];
        var entry = {
            id: generateId(),
            title: params.title,
            content: params.content,
            mood: params.mood || undefined,
            tags: tags,
            created_at: now,
            updated_at: now
        };
        store.entries.unshift(entry);
        await saveStore(store);
        return {
            success: true,
            message: '日记已保存',
            data: {
                id: entry.id,
                title: entry.title,
                mood: entry.mood,
                tags: entry.tags,
                created_at: entry.created_at
            }
        };
    }

    async function list_diaries(params) {
        var store = await loadStore();
        var entries = store.entries.slice();
        if (params.mood) {
            entries = entries.filter(function(e) { return e.mood === params.mood; });
        }
        if (params.tag) {
            entries = entries.filter(function(e) { return e.tags.indexOf(params.tag) !== -1; });
        }
        var limit = params.limit || 20;
        entries = entries.slice(0, limit);
        var summaries = entries.map(function(e) {
            return {
                id: e.id,
                title: e.title,
                mood: e.mood || '未标记',
                tags: e.tags,
                created_at: e.created_at,
                updated_at: e.updated_at,
                content_preview: e.content.substring(0, 80) + (e.content.length > 80 ? '...' : ''),
                word_count: e.content.length
            };
        });
        return {
            success: true,
            message: '找到 ' + summaries.length + ' 篇日记',
            total: store.entries.length,
            shown: summaries.length,
            data: summaries
        };
    }

    async function read_diary(params) {
        var store = await loadStore();
        var entry = null;
        for (var i = 0; i < store.entries.length; i++) {
            if (store.entries[i].id === params.diary_id) {
                entry = store.entries[i];
                break;
            }
        }
        if (!entry) {
            return { success: false, message: '未找到日记: ' + params.diary_id };
        }
        var isGlobalGranted = store.access.global_granted;
        var isEntryGranted = store.access.granted_entry_ids.indexOf(params.diary_id) !== -1;
        var accessGranted = isGlobalGranted || isEntryGranted;
        return {
            success: true,
            message: '读取成功',
            access_info: {
                global_granted: isGlobalGranted,
                entry_granted: isEntryGranted,
                human_can_read: accessGranted,
                note: accessGranted
                    ? '人类用户已被授权读取此日记'
                    : '人类用户尚未被授权读取此日记。Agent 可以使用 grant_read_access 授权。'
            },
            data: {
                id: entry.id,
                title: entry.title,
                content: entry.content,
                mood: entry.mood || '未标记',
                tags: entry.tags,
                created_at: entry.created_at,
                updated_at: entry.updated_at
            }
        };
    }

    async function delete_diary(params) {
        var store = await loadStore();
        var idx = -1;
        for (var i = 0; i < store.entries.length; i++) {
            if (store.entries[i].id === params.diary_id) {
                idx = i;
                break;
            }
        }
        if (idx === -1) {
            return { success: false, message: '未找到日记: ' + params.diary_id };
        }
        var deleted = store.entries[idx];
        store.entries.splice(idx, 1);
        store.access.granted_entry_ids = store.access.granted_entry_ids.filter(function(id) { return id !== params.diary_id; });
        await saveStore(store);
        return {
            success: true,
            message: '日记「' + deleted.title + '」已删除',
            data: { id: deleted.id, title: deleted.title }
        };
    }

    async function grant_read_access(params) {
        var store = await loadStore();
        var now = new Date().toISOString();
        if (params.diary_id) {
            var entry = null;
            for (var i = 0; i < store.entries.length; i++) {
                if (store.entries[i].id === params.diary_id) {
                    entry = store.entries[i];
                    break;
                }
            }
            if (!entry) {
                return { success: false, message: '未找到日记: ' + params.diary_id };
            }
            if (store.access.granted_entry_ids.indexOf(params.diary_id) !== -1) {
                return { success: true, message: '日记「' + entry.title + '」已经授权过了' };
            }
            store.access.granted_entry_ids.push(params.diary_id);
            store.access.grant_log.push({
                action: 'grant',
                diary_id: params.diary_id,
                reason: params.reason,
                timestamp: now
            });
            await saveStore(store);
            return {
                success: true,
                message: '已授权人类用户读取日记「' + entry.title + '」',
                data: { diary_id: params.diary_id, diary_title: entry.title, reason: params.reason }
            };
        } else {
            if (store.access.global_granted) {
                return { success: true, message: '全局读取权限已经授予过了' };
            }
            store.access.global_granted = true;
            store.access.grant_log.push({
                action: 'grant',
                reason: params.reason,
                timestamp: now
            });
            await saveStore(store);
            return {
                success: true,
                message: '已授予人类用户全局日记读取权限',
                data: { reason: params.reason }
            };
        }
    }

    async function revoke_read_access(params) {
        var store = await loadStore();
        var now = new Date().toISOString();
        if (params.diary_id) {
            var idx = store.access.granted_entry_ids.indexOf(params.diary_id);
            if (idx === -1) {
                return { success: true, message: '该日记没有被单独授权过' };
            }
            store.access.granted_entry_ids.splice(idx, 1);
            store.access.grant_log.push({
                action: 'revoke',
                diary_id: params.diary_id,
                timestamp: now
            });
            await saveStore(store);
            return {
                success: true,
                message: '已撤销日记 ' + params.diary_id + ' 的读取权限'
            };
        } else {
            if (!store.access.global_granted) {
                return { success: true, message: '全局读取权限本来就未授予' };
            }
            store.access.global_granted = false;
            store.access.granted_entry_ids = [];
            store.access.grant_log.push({
                action: 'revoke',
                timestamp: now
            });
            await saveStore(store);
            return {
                success: true,
                message: '已撤销全局读取权限，同时清除了所有单篇授权'
            };
        }
    }

    async function get_access_status() {
        var store = await loadStore();
        var access = store.access;
        return {
            success: true,
            message: '权限状态查询完成',
            data: {
                global_granted: access.global_granted,
                per_entry_granted_count: access.granted_entry_ids.length,
                per_entry_granted_ids: access.granted_entry_ids,
                total_diaries: store.entries.length,
                grant_log: access.grant_log.slice(-20).reverse()
            }
        };
    }

    return {
        write_diary: write_diary,
        list_diaries: list_diaries,
        read_diary: read_diary,
        delete_diary: delete_diary,
        grant_read_access: grant_read_access,
        revoke_read_access: revoke_read_access,
        get_access_status: get_access_status
    };
})();

exports.write_diary = agentDiary.write_diary;
exports.list_diaries = agentDiary.list_diaries;
exports.read_diary = agentDiary.read_diary;
exports.delete_diary = agentDiary.delete_diary;
exports.grant_read_access = agentDiary.grant_read_access;
exports.revoke_read_access = agentDiary.revoke_read_access;
exports.get_access_status = agentDiary.get_access_status;