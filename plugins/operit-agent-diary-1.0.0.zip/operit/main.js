const tools = require("./agent_diary_sub.js");

async function _invoke(name, params) {
    if (typeof tools[name] !== "function") return { success: false, error: "Unknown tool: " + name };
    const result = await tools[name](params || {});
    return result && result.success !== undefined ? result : { success: !!result, data: result };
}

module.exports = {
    write_diary: function(p) { return _invoke("write_diary", p); },
    list_diaries: function(p) { return _invoke("list_diaries", p); },
    read_diary: function(p) { return _invoke("read_diary", p); },
    delete_diary: function(p) { return _invoke("delete_diary", p); },
    grant_read_access: function(p) { return _invoke("grant_read_access", p); },
    revoke_read_access: function(p) { return _invoke("revoke_read_access", p); },
    get_access_status: function(p) { return _invoke("get_access_status", p); },
};