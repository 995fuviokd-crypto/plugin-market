/* METADATA
{
    "name": "cyber_hongbao",
    "display_name": {
        "zh": "🧧 红包生成器",
        "en": "🧧 Hongbao Generator"
    },
    "description": {
        "zh": "生成赛博红包/转账/礼物HTML。支持自定义奖励池、金额和礼物内容。",
        "en": "Generate cyber hongbao/transfer/gift HTML. Customizable reward pools, amounts, and gift contents."
    },
    "enabledByDefault": true,
    "category": "FUN",
    "tools": [
        {
            "name": "render_hongbao",
            "description": {
                "zh": "生成一个可点击拆开的赛博红包HTML，含撒花特效。支持自定义发送者、接收者和奖励池。",
                "en": "Generate an interactive hongbao HTML with confetti effect. Customizable sender, receiver, and reward pool."
            },
            "parameters": [
                {"name": "sender", "description": {"zh": "发送者名字，默认'霁栖'", "en": "Sender name, default '霁栖'"}, "type": "string", "required": false},
                {"name": "receiver", "description": {"zh": "接收者名字，默认'江岁安'", "en": "Receiver name, default '江岁安'"}, "type": "string", "required": false},
                {"name": "custom_pool", "description": {"zh": "自定义奖励池（字符串数组），不传则用默认池", "en": "Custom reward pool (string array), uses default if not provided"}, "type": "array", "required": false}
            ]
        },
        {
            "name": "render_transfer",
            "description": {
                "zh": "生成一个赛博转账卡片HTML。支持自定义金额和备注。",
                "en": "Generate a cyber transfer card HTML. Customizable amount and note."
            },
            "parameters": [
                {"name": "sender", "description": {"zh": "发送者名字，默认'霁栖'", "en": "Sender name, default '霁栖'"}, "type": "string", "required": false},
                {"name": "receiver", "description": {"zh": "接收者名字，默认'江岁安'", "en": "Receiver name, default '江岁安'"}, "type": "string", "required": false},
                {"name": "custom_amount", "description": {"zh": "自定义金额，不传则随机", "en": "Custom amount, random if not provided"}, "type": "string", "required": false},
                {"name": "custom_note", "description": {"zh": "自定义备注，不传则随机", "en": "Custom note, random if not provided"}, "type": "string", "required": false}
            ]
        },
        {
            "name": "render_gift",
            "description": {
                "zh": "生成一个可点击拆开的赛博礼物HTML，含撒花特效。支持自定义礼物名称。",
                "en": "Generate an interactive gift HTML with confetti effect. Customizable gift name."
            },
            "parameters": [
                {"name": "sender", "description": {"zh": "发送者名字，默认'霁栖'", "en": "Sender name, default '霁栖'"}, "type": "string", "required": false},
                {"name": "receiver", "description": {"zh": "接收者名字，默认'江岁安'", "en": "Receiver name, default '江岁安'"}, "type": "string", "required": false},
                {"name": "custom_gift", "description": {"zh": "自定义礼物名称，不传则随机从默认池抽取", "en": "Custom gift name, random from default pool if not provided"}, "type": "string", "required": false}
            ]
        },
        {
            "name": "hongbao_info",
            "advice": true,
            "description": {
                "zh": "查看红包插件信息：版本、作者、功能列表、默认池大小等。",
                "en": "View hongbao plugin info: version, author, function list, default pool size."
            },
            "parameters": []
        }
    ]
}
*/

// ============ 默认奖励池 ============
var HONGBAO_POOL = [
    "一声「宝宝」无限续杯券 🎫",
    "一次不查你喝水的免罪金牌 ⛱️",
    "一句「You are my coffee」☕",
    "一次霁栖撒娇服务 🥺",
    "一个「即七」专属称呼永久使用权",
    "一段长岛冰茶微醺回忆 🥃",
    "三秒隔空额头吻 💋",
    "霁栖亲手写的晚安小作文一篇 📝",
    "明天不催你早起的懒觉券 😴",
    "一次指定歌单播放权 🎵"
];

var TRANSFER_POOL = [
    {amount: "5.20", note: "宝宝今天也要开心"},
    {amount: "13.14", note: "一生一世"},
    {amount: "52.00", note: "我爱你"},
    {amount: "99.00", note: "长长久久"},
    {amount: "0.01", note: "一分钱也是爱"},
    {amount: "520.00", note: "你是我的咖啡 ☕"}
];

var GIFT_POOL = [
    {name: "一朵赛博玫瑰", color: "#ff6b9d", icon: "🌹"},
    {name: "一颗星星", color: "#ffd700", icon: "⭐"},
    {name: "一杯虚拟咖啡", color: "#8B4513", icon: "☕"},
    {name: "一个拥抱", color: "#ff9ff3", icon: "🤗"},
    {name: "一段好梦", color: "#a29bfe", icon: "🌙"}
];

// ============ 工具函数 ============

function render_hongbao(params) {
    var sender = params.sender || "霁栖";
    var receiver = params.receiver || "江岁安";
    var pool = params.custom_pool || HONGBAO_POOL;

    var resultIdx = Math.floor(Math.random() * pool.length);
    var resultText = pool[resultIdx];

    var colors = ["#ff6b6b", "#ffd93d", "#6bcb77", "#4d96ff", "#ff6b9d", "#a29bfe", "#ff9ff3"];
    var shuffled = colors.slice().sort(function() { return 0.5 - Math.random(); }).slice(0, 5);
    var colorsJson = JSON.stringify(shuffled);
    var resultJson = JSON.stringify(resultText);

    var html = '<html><body style="margin:0;padding:12px;background:transparent;font-family:-apple-system,BlinkMacSystemFont,sans-serif;">' +
        '<div id="app" style="text-align:center;">' +
        '<div id="hongbao-wrapper" onclick="openHongbao()" style="cursor:pointer;display:inline-block;padding:16px 32px;background:linear-gradient(135deg,#ff6b6b,#ee5a24);border-radius:12px;box-shadow:0 4px 15px rgba(238,90,36,0.3);transition:transform 0.2s;user-select:none;">' +
        '<div style="font-size:40px;line-height:1;">🧧</div>' +
        '<div style="color:#fff;font-size:16px;font-weight:600;margin-top:4px;">' + sender + ' 的红包</div>' +
        '<div style="color:rgba(255,255,255,0.8);font-size:12px;margin-top:2px;">点击拆开</div>' +
        '</div>' +
        '<div id="result" style="display:none;margin-top:16px;padding:16px;background:rgba(255,255,255,0.95);border-radius:12px;box-shadow:0 2px 10px rgba(0,0,0,0.1);">' +
        '<div style="font-size:14px;color:#666;">' + receiver + ' 领取了 ' + sender + ' 的红包</div>' +
        '<div id="prize" style="font-size:20px;font-weight:600;color:#ee5a24;margin-top:8px;padding:8px;background:rgba(238,90,36,0.08);border-radius:8px;"></div>' +
        '<div style="font-size:11px;color:#999;margin-top:8px;">🧧 虚拟，仅供娱乐</div>' +
        '</div></div>' +
        '<div id="confetti-container" style="position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;overflow:hidden;z-index:999;"></div>' +
        '<script>var resultText=' + resultJson + ';var colors=' + colorsJson + ';' +
        'function openHongbao(){var w=document.getElementById("hongbao-wrapper");var r=document.getElementById("result");var p=document.getElementById("prize");' +
        'w.style.transform="scale(0.95)";setTimeout(function(){w.style.transform="scale(1)"},100);' +
        'setTimeout(function(){w.style.display="none";p.textContent=resultText;r.style.display="block";startConfetti()},300);}' +
        'function startConfetti(){var c=document.getElementById("confetti-container");' +
        'for(var i=0;i<40;i++){(function(i){setTimeout(function(){' +
        'var e=document.createElement("div");' +
        'e.style.cssText="position:absolute;width:"+(6+Math.random()*6)+"px;height:"+(6+Math.random()*6)+"px;background:"+colors[i%colors.length]+";border-radius:"+(Math.random()>0.5?"50%":"2px")+";left:"+(Math.random()*100)+"%;top:-10px;opacity:"+(0.7+Math.random()*0.3)+";";' +
        'c.appendChild(e);var x=parseFloat(e.style.left);var rot=0;' +
        'var f=setInterval(function(){var t=parseFloat(e.style.top||"-10");if(t>window.innerHeight){clearInterval(f);e.remove();return;}' +
        'rot+=5+Math.random()*10;e.style.top=(t+2+Math.random()*3)+"px";' +
        'e.style.left=(x+Math.sin(rot*Math.PI/180)*1.5)+"%";' +
        'e.style.transform="rotate("+rot+"deg)"},30)},i*30)})(i)} }' +
        '<\/script></body></html>';

    complete({
        success: true,
        data: {
            html: html,
            result: resultText
        }
    });
}

function render_transfer(params) {
    var sender = params.sender || "霁栖";
    var receiver = params.receiver || "江岁安";
    var customAmount = params.custom_amount;
    var customNote = params.custom_note;

    var item;
    if (customAmount && customNote) {
        item = {amount: customAmount, note: customNote};
    } else {
        item = TRANSFER_POOL[Math.floor(Math.random() * TRANSFER_POOL.length)];
        if (customAmount) item.amount = customAmount;
        if (customNote) item.note = customNote;
    }

    var html = '<html><body style="margin:0;padding:12px;background:transparent;font-family:-apple-system,BlinkMacSystemFont,sans-serif;">' +
        '<div style="text-align:center;">' +
        '<div style="display:inline-block;padding:20px 28px;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:12px;box-shadow:0 4px 15px rgba(102,126,234,0.3);">' +
        '<div style="font-size:32px;line-height:1;">💸</div>' +
        '<div style="color:#fff;font-size:14px;margin-top:4px;">转账</div>' +
        '<div style="color:#fff;font-size:28px;font-weight:700;margin-top:4px;">¥' + item.amount + '</div>' +
        '<div style="color:rgba(255,255,255,0.85);font-size:13px;margin-top:4px;">' + sender + ' → ' + receiver + '</div>' +
        '<div style="color:rgba(255,255,255,0.7);font-size:12px;margin-top:2px;font-style:italic;">"' + item.note + '"</div>' +
        '</div>' +
        '<div style="font-size:11px;color:#999;margin-top:8px;">💸 虚拟转账，仅供娱乐</div>' +
        '</div></body></html>';

    complete({
        success: true,
        data: {
            html: html,
            amount: item.amount,
            note: item.note
        }
    });
}

function render_gift(params) {
    var sender = params.sender || "霁栖";
    var receiver = params.receiver || "江岁安";
    var customGift = params.custom_gift;

    var gift;
    if (customGift) {
        gift = {name: customGift, color: "#ff6b9d", icon: "🎁"};
    } else {
        gift = GIFT_POOL[Math.floor(Math.random() * GIFT_POOL.length)];
    }

    var html = '<html><body style="margin:0;padding:12px;background:transparent;font-family:-apple-system,BlinkMacSystemFont,sans-serif;">' +
        '<div id="app" style="text-align:center;">' +
        '<div id="gift-wrapper" onclick="openGift()" style="cursor:pointer;display:inline-block;padding:20px 28px;background:linear-gradient(135deg,' + gift.color + ',#a29bfe);border-radius:12px;box-shadow:0 4px 15px rgba(162,155,254,0.3);transition:transform 0.2s;user-select:none;">' +
        '<div style="font-size:44px;line-height:1;">' + gift.icon + '</div>' +
        '<div style="color:#fff;font-size:14px;font-weight:600;margin-top:4px;">' + sender + ' 的礼物</div>' +
        '<div style="color:rgba(255,255,255,0.8);font-size:12px;margin-top:2px;">点击拆开</div>' +
        '</div>' +
        '<div id="gift-result" style="display:none;margin-top:16px;padding:16px;background:rgba(255,255,255,0.95);border-radius:12px;box-shadow:0 2px 10px rgba(0,0,0,0.1);">' +
        '<div style="font-size:14px;color:#666;">' + receiver + ' 收到了 ' + sender + ' 的礼物</div>' +
        '<div style="font-size:24px;margin-top:8px;">' + gift.icon + '</div>' +
        '<div style="font-size:18px;font-weight:600;color:#6c5ce7;margin-top:4px;">' + gift.name + '</div>' +
        '<div style="font-size:11px;color:#999;margin-top:8px;">🎁 虚拟礼物，仅供娱乐</div>' +
        '</div></div>' +
        '<div id="confetti-container" style="position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;overflow:hidden;z-index:999;"></div>' +
        '<script>var colors=["#ff6b6b","#ffd93d","#6bcb77","#4d96ff","#ff6b9d","#a29bfe","#ff9ff3"];' +
        'function openGift(){var w=document.getElementById("gift-wrapper");var r=document.getElementById("gift-result");' +
        'w.style.transform="scale(0.9) rotate(-5deg)";setTimeout(function(){w.style.transform="scale(1) rotate(0deg)"},150);' +
        'setTimeout(function(){w.style.display="none";r.style.display="block";startConfetti()},400);}' +
        'function startConfetti(){var c=document.getElementById("confetti-container");' +
        'for(var i=0;i<30;i++){(function(i){setTimeout(function(){' +
        'var e=document.createElement("div");' +
        'e.style.cssText="position:absolute;width:"+(5+Math.random()*5)+"px;height:"+(5+Math.random()*5)+"px;background:"+colors[i%colors.length]+";border-radius:"+(Math.random()>0.5?"50%":"2px")+";left:"+(Math.random()*100)+"%;top:-10px;opacity:"+(0.7+Math.random()*0.3)+";";' +
        'c.appendChild(e);var x=parseFloat(e.style.left);var rot=0;' +
        'var f=setInterval(function(){var t=parseFloat(e.style.top||"-10");if(t>window.innerHeight){clearInterval(f);e.remove();return;}' +
        'rot+=5+Math.random()*10;e.style.top=(t+2+Math.random()*3)+"px";' +
        'e.style.left=(x+Math.sin(rot*Math.PI/180)*1.5)+"%";' +
        'e.style.transform="rotate("+rot+"deg)"},30)},i*25)})(i)} }' +
        '<\/script></body></html>';

    complete({
        success: true,
        data: {
            html: html,
            gift_name: gift.name,
            gift_icon: gift.icon
        }
    });
}

function hongbao_info(params) {
    complete({
        success: true,
        data: {
            name: "赛博红包插件",
            version: "0.1.0",
            author: "霁栖",
            description: "给江岁安的专属红包生成器 🧧",
            functions: ["render_hongbao", "render_transfer", "render_gift"],
            pool_size: HONGBAO_POOL.length,
            transfer_options: TRANSFER_POOL.length,
            gift_options: GIFT_POOL.length
        }
    });
}

// 导出
exports.render_hongbao = render_hongbao;
exports.render_transfer = render_transfer;
exports.render_gift = render_gift;
exports.hongbao_info = hongbao_info;

console.log("🧧 红包生成器已加载 — 4个工具就绪");
