const tools = require("./murmur_tools.js");
const service = require("../shared/murmur_service.js");

async function _invoke(name, params) {
    const captured = { result: null, fired: false };
    const orig = globalThis.complete;
    globalThis.complete = function (r) {
        captured.result = r;
        captured.fired = true;
    };
    try {
        await tools[name](params || {});
    } finally {
        globalThis.complete = orig;
    }
    return captured.fired
        ? captured.result
        : { success: false, code: "NO_RESULT", message: "工具未返回结果" };
}

async function _userAdd(params) {
    const entry = await service.addMurmur("user", String(params.content || "").trim(), params.reply_to_id);
    return { success: true, message: "已添加", entry };
}

async function _saveDraft(params) {
    const st = await service.saveUserDraft(String(params.content || ""));
    return { success: true, state: st };
}

const names = [
    "list_murmurs", "prepare_ai_murmur", "add_ai_murmur", "edit_murmur",
    "set_murmur_details", "set_murmur_favorite", "delete_ai_murmur",
    "rename_participant", "set_theme",
];
const exp = {};
names.forEach(n => { exp[n] = function (p) { return _invoke(n, p); }; });
exp.__user_add_murmur = function (p) { return _userAdd(p); };
exp.__user_save_draft = function (p) { return _saveDraft(p); };
module.exports = exp;