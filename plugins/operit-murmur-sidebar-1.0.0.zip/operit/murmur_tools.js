"use strict";
/* METADATA
{
  "name": "murmur_sidebar_tools",
  "display_name": { "zh": "碎碎念工具", "en": "Murmur Tools" },
  "description": { "zh": "读取和管理用户与 AI 共享的碎碎念侧边栏。AI 可写自己的分区、编辑双方内容，但只能删除 AI 自己的内容。", "en": "Read and manage the shared user/AI murmur sidebar. The AI writes its own section, may edit either section, and may only delete its own entries." },
  "category": "Utility",
  "tools": [
    { "name": "list_murmurs", "description": { "zh": "读取双方碎碎念；可按日期范围筛选，开始和结束日期均包含。", "en": "Read both participants' murmurs, optionally filtered by an inclusive date range." }, "parameters": [
      { "name": "start_date", "description": { "zh": "可选开始日期 YYYY-MM-DD", "en": "Optional start date YYYY-MM-DD" }, "type": "string", "required": false },
      { "name": "end_date", "description": { "zh": "可选结束日期 YYYY-MM-DD", "en": "Optional end date YYYY-MM-DD" }, "type": "string", "required": false }
    ] },
    { "name": "prepare_ai_murmur", "description": { "zh": "AI 写碎碎念前必须先调用：自动读取用户最近三条碎碎念并返回一次性写入令牌。", "en": "Required before writing: read the user's latest three murmurs and return a one-time write token." }, "parameters": [] },
    { "name": "add_ai_murmur", "description": { "zh": "在 AI 分区新增碎碎念；必须先调用 prepare_ai_murmur，并携带其令牌。可选引用已有碎碎念。", "en": "Add an AI murmur after prepare_ai_murmur, using its token; optionally quote an entry." }, "parameters": [
      { "name": "content", "description": { "zh": "碎碎念正文", "en": "Murmur text" }, "type": "string", "required": true },
      { "name": "prepare_token", "description": { "zh": "prepare_ai_murmur 返回的一次性令牌", "en": "One-time token from prepare_ai_murmur" }, "type": "string", "required": true },
      { "name": "reply_to_id", "description": { "zh": "可选：要引用回复的碎碎念 ID", "en": "Optional entry ID to quote" }, "type": "string", "required": false }
    ] },
    { "name": "edit_murmur", "description": { "zh": "编辑任意一方已有的碎碎念。先用 list_murmurs 获取 ID。", "en": "Edit an existing murmur from either participant. Use list_murmurs to obtain its ID." }, "parameters": [
      { "name": "id", "description": { "zh": "记录 ID", "en": "Entry ID" }, "type": "string", "required": true },
      { "name": "content", "description": { "zh": "新的正文", "en": "New text" }, "type": "string", "required": true }
    ] },
    { "name": "set_murmur_details", "description": { "zh": "由 AI 设置心情或置顶。", "en": "Set mood or pinned state." }, "parameters": [
      { "name": "id", "description": { "zh": "碎碎念 ID", "en": "Murmur ID" }, "type": "string", "required": true },
      { "name": "mood", "description": { "zh": "心情：可用 happy/calm/sad/tired/miss/none，或填写 1-20 个字符的自定义心情文字", "en": "Mood: happy/calm/sad/tired/miss/none, or custom mood text of 1-20 characters" }, "type": "string", "required": false },
      { "name": "pinned", "description": { "zh": "是否置顶", "en": "Whether pinned" }, "type": "boolean", "required": false }
    ] },
    { "name": "set_murmur_favorite", "description": { "zh": "由 AI 收藏或取消收藏任意一方的碎碎念。先用 list_murmurs 获取 ID 和当前 favorite 状态。", "en": "Let the AI favorite or unfavorite either participant's murmur. Use list_murmurs for its ID and current favorite state." }, "parameters": [
      { "name": "id", "description": { "zh": "碎碎念 ID", "en": "Murmur ID" }, "type": "string", "required": true },
      { "name": "favorite", "description": { "zh": "true 为收藏，false 为取消收藏", "en": "true to favorite, false to unfavorite" }, "type": "boolean", "required": true }
    ] },
    { "name": "delete_ai_murmur", "description": { "zh": "删除一条由 AI 写入的碎碎念；不能删除用户内容。", "en": "Delete an AI-authored murmur; user entries cannot be deleted." }, "parameters": [
      { "name": "id", "description": { "zh": "AI 记录 ID", "en": "AI entry ID" }, "type": "string", "required": true }
    ] },
    { "name": "rename_participant", "description": { "zh": "修改用户或 AI 在侧边栏中的显示名。", "en": "Rename the user or AI in the sidebar." }, "parameters": [
      { "name": "target", "description": { "zh": "user 或 ai", "en": "user or ai" }, "type": "string", "required": true },
      { "name": "name", "description": { "zh": "新名称，最多 24 个字符", "en": "New name, up to 24 characters" }, "type": "string", "required": true }
    ] },
    { "name": "set_theme", "description": { "zh": "设置内置主题或四项自定义颜色。内置主题为 coral、forest、ocean、graphite；custom 模式需提供全部 #RRGGBB 颜色。", "en": "Set a preset or four custom colors. Presets: coral, forest, ocean, graphite; custom requires all #RRGGBB colors." }, "parameters": [
      { "name": "preset", "description": { "zh": "内置主题名或 custom", "en": "Preset name or custom" }, "type": "string", "required": true },
      { "name": "primary", "description": { "zh": "自定义主色", "en": "Custom primary color" }, "type": "string", "required": false },
      { "name": "background", "description": { "zh": "自定义背景色", "en": "Custom background color" }, "type": "string", "required": false },
      { "name": "surface", "description": { "zh": "自定义表面色", "en": "Custom surface color" }, "type": "string", "required": false },
      { "name": "text", "description": { "zh": "自定义文字色", "en": "Custom text color" }, "type": "string", "required": false }
    ] }
  ]
}
*/
Object.defineProperty(exports, "__esModule", { value: true });
const murmur_service_js_1 = require("../shared/murmur_service.js");
let pendingPrepare = null;
async function wrap(handler, params) {
    try {
        complete(await handler(params));
    }
    catch (error) {
        const handled = error;
        complete({ success: false, code: handled.code || "ERROR", message: handled.message || String(error) });
    }
}
async function listMurmurs(params = {}) {
    const state = await (0, murmur_service_js_1.readState)();
    const start = String(params.start_date || "").trim();
    const end = String(params.end_date || "").trim();
    const pattern = /^\d{4}-\d{2}-\d{2}$/;
    if ((start && !pattern.test(start)) || (end && !pattern.test(end)) || (start && end && start > end)) {
        throw Object.assign(new Error("日期格式应为 YYYY-MM-DD，且开始日期不能晚于结束日期"), { code: "INVALID_DATE_RANGE" });
    }
    const entries = state.entries.filter(item => {
        const date = new Date(item.createdAt);
        const day = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
        return (!start || day >= start) && (!end || day <= end);
    });
    return { success: true, names: state.names, theme: state.theme, date_range: { start_date: start || null, end_date: end || null }, user: entries.filter(item => item.author === "user"), ai: entries.filter(item => item.author === "ai") };
}
async function prepareAiMurmur() {
    const state = await (0, murmur_service_js_1.readState)();
    const recentUserMurmurs = state.entries
        .filter(item => item.author === "user")
        .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
        .slice(0, 3);
    const token = `prepare_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
    pendingPrepare = { token, expiresAt: Date.now() + 5 * 60 * 1000 };
    return { success: true, message: "已读取用户最近三条碎碎念；请结合它们决定要写的内容", recent_user_murmurs: recentUserMurmurs, prepare_token: token, expires_in_seconds: 300 };
}
async function addAiMurmur(params) {
    if (!pendingPrepare || pendingPrepare.token !== String(params.prepare_token || "") || pendingPrepare.expiresAt < Date.now()) {
        throw Object.assign(new Error("写入前必须先调用 prepare_ai_murmur 读取用户最近三条碎碎念"), { code: "PREPARE_REQUIRED" });
    }
    pendingPrepare = null;
    const entry = await (0, murmur_service_js_1.addMurmur)("ai", params.content, params.reply_to_id);
    return { success: true, message: "AI 碎碎念已添加", entry };
}
async function editAnyMurmur(params) {
    const entry = await (0, murmur_service_js_1.editMurmur)(params.id, params.content);
    return { success: true, message: "碎碎念已更新", entry };
}
async function setDetails(params) {
    let entry = null;
    if (params.mood !== undefined) {
        const mood = String(params.mood).trim();
        if (!mood || mood.length > 20)
            throw Object.assign(new Error("mood 必须是 1-20 个字符"), { code: "INVALID_MOOD" });
        entry = await (0, murmur_service_js_1.setMurmurMood)(params.id, mood);
    }
    if (params.pinned !== undefined)
        entry = await (0, murmur_service_js_1.setMurmurPinned)(params.id, params.pinned);
    if (entry === null)
        throw Object.assign(new Error("至少提供 mood 或 pinned 之一"), { code: "NO_CHANGES" });
    return { success: true, message: "碎碎念状态已更新", entry };
}
async function setFavorite(params) {
    if (typeof params.favorite !== "boolean") {
        throw Object.assign(new Error("favorite 必须是 true 或 false"), { code: "INVALID_FAVORITE" });
    }
    const entry = await (0, murmur_service_js_1.setMurmurFavorite)(params.id, params.favorite);
    return { success: true, message: entry.favorite ? "AI 已收藏这条碎碎念" : "AI 已取消收藏这条碎碎念", entry };
}
async function deleteAiMurmur(params) {
    const entry = await (0, murmur_service_js_1.deleteMurmur)("ai", params.id);
    return { success: true, message: "AI 碎碎念已删除", entry };
}
async function rename(params) {
    const state = await (0, murmur_service_js_1.renameParticipant)(params.target, params.name);
    return { success: true, message: "名称已更新", names: state.names };
}
async function setTheme(params) {
    const state = params.preset === "custom"
        ? await (0, murmur_service_js_1.setCustomTheme)(params)
        : await (0, murmur_service_js_1.setPresetTheme)(params.preset);
    return { success: true, message: "主题已更新", theme: state.theme };
}
exports.list_murmurs = (params) => wrap(listMurmurs, params || {});
exports.prepare_ai_murmur = (params) => wrap(prepareAiMurmur, params);
exports.add_ai_murmur = (params) => wrap(addAiMurmur, params);
exports.edit_murmur = (params) => wrap(editAnyMurmur, params);
exports.set_murmur_details = (params) => wrap(setDetails, params);
exports.set_murmur_favorite = (params) => wrap(setFavorite, params);
exports.delete_ai_murmur = (params) => wrap(deleteAiMurmur, params);
exports.rename_participant = (params) => wrap(rename, params);
exports.set_theme = (params) => wrap(setTheme, params);
