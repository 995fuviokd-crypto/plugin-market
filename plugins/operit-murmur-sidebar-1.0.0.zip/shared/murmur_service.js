"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.THEME_PRESETS = void 0;
exports.isHexColor = isHexColor;
exports.normalizeState = normalizeState;
exports.getStateFile = getStateFile;
exports.getCachedState = getCachedState;
exports.preloadState = preloadState;
exports.readState = readState;
exports.writeState = writeState;
exports.addMurmur = addMurmur;
exports.editMurmur = editMurmur;
exports.setMurmurFavorite = setMurmurFavorite;
exports.saveUserDraft = saveUserDraft;
exports.exportMurmurs = exportMurmurs;
exports.setMurmurPinned = setMurmurPinned;
exports.setMurmurMood = setMurmurMood;
exports.deleteMurmur = deleteMurmur;
exports.renameParticipant = renameParticipant;
exports.setPresetTheme = setPresetTheme;
exports.setDisplayMode = setDisplayMode;
exports.setBackgroundImage = setBackgroundImage;
exports.setAppearanceOptions = setAppearanceOptions;
exports.setCustomTheme = setCustomTheme;
exports.THEME_PRESETS = {
    coral: { preset: "coral", displayMode: "dark", primary: "#B93850", background: "#FFF8F7", surface: "#FFE7E5", text: "#251819" },
    forest: { preset: "forest", displayMode: "dark", primary: "#267257", background: "#F6FAF7", surface: "#DDEFE4", text: "#15231C" },
    ocean: { preset: "ocean", displayMode: "dark", primary: "#146C94", background: "#F5FAFC", surface: "#DCEFF7", text: "#132229" },
    graphite: { preset: "graphite", displayMode: "dark", primary: "#525866", background: "#F8F8F9", surface: "#E9EAED", text: "#1C1D21" }
};
const DEFAULT_STATE = {
    version: 1,
    names: { user: "我", ai: "AI" },
    theme: { ...exports.THEME_PRESETS.coral },
    backgroundImage: "",
    backgroundImageOpacity: 0.22,
    frostedBubbles: false,
    userDraft: "",
    entries: []
};
// 主入口与 Compose DSL 页面引用同一个 CommonJS 服务模块。
// 插件注册时预热此缓存，页面首次渲染即可同步取得持久化状态。
let stateCache = normalizeState(DEFAULT_STATE);
let preloadPromise = null;
function fail(code, message) {
    const error = new Error(message);
    error.code = code;
    throw error;
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function normalizeAuthor(value) {
    return value === "user" || value === "ai" ? value : null;
}
function normalizeName(value, fallback) {
    const name = String(value ?? "").trim();
    return name && name.length <= 24 ? name : fallback;
}
function requireName(value) {
    const name = String(value ?? "").trim();
    if (!name)
        fail("INVALID_NAME", "名称不能为空");
    if (name.length > 24)
        fail("INVALID_NAME", "名称不能超过 24 个字符");
    return name;
}
function requireContent(value) {
    const content = String(value ?? "").trim();
    if (!content)
        fail("INVALID_CONTENT", "碎碎念内容不能为空");
    if (content.length > 4000)
        fail("INVALID_CONTENT", "碎碎念内容不能超过 4000 个字符");
    return content;
}
function isHexColor(value) {
    return /^#[0-9a-fA-F]{6}$/.test(String(value ?? ""));
}
function normalizeTheme(value) {
    if (!isRecord(value))
        return { ...exports.THEME_PRESETS.coral };
    const preset = String(value.preset ?? "coral");
    const base = exports.THEME_PRESETS[preset] || exports.THEME_PRESETS.coral;
    const displayMode = value.displayMode === "auto" || value.displayMode === "light" || value.displayMode === "dark"
        ? value.displayMode
        : "dark";
    return {
        preset: exports.THEME_PRESETS[preset] ? preset : "custom",
        displayMode,
        primary: isHexColor(value.primary) ? value.primary.toUpperCase() : base.primary,
        background: isHexColor(value.background) ? value.background.toUpperCase() : base.background,
        surface: isHexColor(value.surface) ? value.surface.toUpperCase() : base.surface,
        text: isHexColor(value.text) ? value.text.toUpperCase() : base.text
    };
}
function normalizeEntry(value) {
    if (!isRecord(value))
        return null;
    const author = normalizeAuthor(value.author);
    const id = String(value.id ?? "").trim();
    const content = String(value.content ?? "").trim();
    if (!author || !id || !content)
        return null;
    const createdAt = String(value.createdAt ?? "").trim() || new Date(0).toISOString();
    const updatedAt = String(value.updatedAt ?? "").trim() || createdAt;
    const reply = isRecord(value.replyTo) ? value.replyTo : null;
    const replyAuthor = reply ? normalizeAuthor(reply.author) : null;
    const replyContent = reply ? String(reply.content ?? "").trim().slice(0, 240) : "";
    const replyTo = reply && replyAuthor && replyContent
        ? { id: String(reply.id ?? "").trim(), author: replyAuthor, content: replyContent }
        : undefined;
    const rawMood = String(value.mood ?? "none").trim();
    const mood = ["happy", "calm", "sad", "tired", "miss", "none"].includes(rawMood) ? rawMood : rawMood.slice(0, 20);
    return { id, author, content: content.slice(0, 4000), createdAt, updatedAt, favorite: value.favorite === true, pinned: value.pinned === true, mood, replyTo };
}
function normalizeState(value) {
    const input = isRecord(value) ? value : {};
    const names = isRecord(input.names) ? input.names : {};
    const entries = Array.isArray(input.entries)
        ? input.entries.map(normalizeEntry).filter((entry) => entry !== null)
        : [];
    return {
        version: 1,
        names: {
            user: normalizeName(names.user, DEFAULT_STATE.names.user),
            ai: normalizeName(names.ai, DEFAULT_STATE.names.ai)
        },
        theme: normalizeTheme(input.theme),
        backgroundImage: String(input.backgroundImage ?? "").trim(),
        backgroundImageOpacity: typeof input.backgroundImageOpacity === "number" && Number.isFinite(input.backgroundImageOpacity)
            ? Math.max(0, Math.min(1, input.backgroundImageOpacity))
            : DEFAULT_STATE.backgroundImageOpacity,
        frostedBubbles: input.frostedBubbles === true,
        userDraft: String(input.userDraft ?? "").slice(0, 4000),
        entries
    };
}
function getStateFile() {
    return `data/state.json`;
}
async function ensureStorage() {
    const dir = "data";
    await Tools.Files.mkdir(dir, true);
    const exists = await Tools.Files.exists(getStateFile());
    if (!exists?.exists)
        await Tools.Files.write(getStateFile(), JSON.stringify(DEFAULT_STATE, null, 2));
}
function getCachedState() {
    // 返回副本，防止 UI 草稿意外修改共享缓存。
    return normalizeState(stateCache);
}
function preloadState() {
    if (!preloadPromise) {
        preloadPromise = readState().finally(() => { preloadPromise = null; });
    }
    return preloadPromise;
}
async function readState() {
    await ensureStorage();
    try {
        const result = await Tools.Files.read(getStateFile());
        stateCache = normalizeState(JSON.parse(String(result?.content || "{}")));
        return getCachedState();
    }
    catch (_error) {
        const recovered = normalizeState(null);
        await writeState(recovered);
        return getCachedState();
    }
}
async function writeState(value) {
    const next = normalizeState(value);
    const file = getStateFile();
    const temp = `${file}.tmp`;
    await Tools.Files.mkdir("data", true);
    await Tools.Files.write(temp, JSON.stringify(next, null, 2), false);
    const current = await Tools.Files.exists(file);
    if (current?.exists)
        await Tools.Files.delete(file);
    await Tools.Files.move(temp, file);
    stateCache = next;
    return getCachedState();
}
async function withLockedState(mutation) {
    await Tools.Files.mkdir("data", true);
    let randomAccessFile = null;
    let channel = null;
    let lock = null;
    try {
        if (typeof Java !== "undefined") {
            const RandomAccessFile = Java.type("java.io.RandomAccessFile");
            randomAccessFile = new RandomAccessFile(`data/state.lock`, "rw");
            channel = randomAccessFile.getChannel();
            lock = channel.lock();
        }
        const state = await readState();
        const result = mutation(state);
        await writeState(state);
        return result;
    }
    finally {
        try {
            if (lock)
                lock.release();
        }
        catch (_error) { }
        try {
            if (channel)
                channel.close();
        }
        catch (_error) { }
        try {
            if (randomAccessFile)
                randomAccessFile.close();
        }
        catch (_error) { }
    }
}
function createId(author) {
    return `${author}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}
async function addMurmur(authorValue, contentValue, replyToIdValue) {
    const author = normalizeAuthor(authorValue);
    if (!author)
        fail("INVALID_AUTHOR", "作者必须是 user 或 ai");
    const content = requireContent(contentValue);
    const replyToId = String(replyToIdValue ?? "").trim();
    return withLockedState(state => {
        const now = new Date().toISOString();
        const source = replyToId ? state.entries.find(item => item.id === replyToId) : undefined;
        if (replyToId && !source)
            fail("REPLY_NOT_FOUND", "要引用的碎碎念不存在");
        const replyTo = source ? { id: source.id, author: source.author, content: source.content.slice(0, 240) } : undefined;
        const entry = { id: createId(author), author, content, createdAt: now, updatedAt: now, favorite: false, pinned: false, mood: "none", replyTo };
        state.entries.push(entry);
        return entry;
    });
}
async function editMurmur(idValue, contentValue) {
    const id = String(idValue ?? "").trim();
    const content = requireContent(contentValue);
    return withLockedState(state => {
        const entry = state.entries.find(item => item.id === id);
        if (!entry)
            fail("NOT_FOUND", "没有找到这条碎碎念");
        entry.content = content;
        // updatedAt records edits; createdAt remains the original publication date.
        entry.updatedAt = new Date().toISOString();
        return entry;
    });
}
async function setMurmurFavorite(idValue, favoriteValue) {
    const id = String(idValue ?? "").trim();
    if (!id)
        fail("INVALID_ID", "碎碎念 ID 不能为空");
    return withLockedState(state => {
        const entry = state.entries.find(item => item.id === id);
        if (!entry)
            fail("NOT_FOUND", "没有找到这条碎碎念");
        entry.favorite = typeof favoriteValue === "boolean" ? favoriteValue : !entry.favorite;
        return entry;
    });
}
async function saveUserDraft(value) {
    const draft = String(value ?? "").slice(0, 4000);
    return withLockedState(state => { state.userDraft = draft; return state; });
}
async function exportMurmurs(formatValue) {
    const state = await readState();
    const format = String(formatValue ?? "json").toLowerCase();
    if (format !== "json" && format !== "markdown")
        fail("INVALID_FORMAT", "导出格式必须是 json 或 markdown");
    const stamp = new Date().toISOString().slice(0, 10);
    const path = `data/murmurs-${stamp}.${format === "json" ? "json" : "md"}`;
    const moodNames = { happy: "开心", calm: "平静", sad: "低落", tired: "疲惫", miss: "想念", none: "" };
    const content = format === "json" ? JSON.stringify(state, null, 2) : ["# 碎碎念备份", "", ...state.entries.slice().sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map(entry => `## ${entry.createdAt.slice(0, 16).replace("T", " ")} · ${state.names[entry.author]}${entry.mood !== "none" ? ` · ${moodNames[entry.mood]}` : ""}${entry.pinned ? " · 置顶" : ""}${entry.favorite ? " · 收藏" : ""}\n\n${entry.content}\n`)].join("\n");
    await Tools.Files.write(path, content, false);
    return path;
}
async function setMurmurPinned(idValue, pinnedValue) {
    const id = String(idValue ?? "").trim();
    if (!id || typeof pinnedValue !== "boolean")
        fail("INVALID_PINNED", "需要有效的 ID 和 pinned 布尔值");
    return withLockedState(state => {
        const entry = state.entries.find(item => item.id === id);
        if (!entry)
            fail("NOT_FOUND", "没有找到这条碎碎念");
        entry.pinned = pinnedValue;
        return entry;
    });
}
async function setMurmurMood(idValue, moodValue) {
    const mood = String(moodValue ?? "none").trim().slice(0, 20) || "none";
    return withLockedState(state => {
        const entry = state.entries.find(item => item.id === String(idValue ?? "").trim());
        if (!entry)
            fail("NOT_FOUND", "没有找到这条碎碎念");
        entry.mood = mood;
        return entry;
    });
}
async function deleteMurmur(actorValue, idValue) {
    const actor = normalizeAuthor(actorValue);
    if (!actor)
        fail("INVALID_ACTOR", "操作者必须是 user 或 ai");
    const id = String(idValue ?? "").trim();
    return withLockedState(state => {
        const index = state.entries.findIndex(item => item.id === id);
        if (index < 0)
            fail("NOT_FOUND", "没有找到这条碎碎念");
        const entry = state.entries[index];
        if (entry.author !== actor)
            fail("FORBIDDEN", "只能删除自己写的碎碎念");
        state.entries.splice(index, 1);
        return entry;
    });
}
async function renameParticipant(targetValue, nameValue) {
    const target = normalizeAuthor(targetValue);
    if (!target)
        fail("INVALID_TARGET", "改名对象必须是 user 或 ai");
    const name = requireName(nameValue);
    return withLockedState(state => {
        state.names[target] = name;
        return state;
    });
}
async function setPresetTheme(presetValue) {
    const preset = String(presetValue ?? "").trim();
    if (!exports.THEME_PRESETS[preset])
        fail("INVALID_THEME", "未知的内置主题");
    return withLockedState(state => {
        state.theme = { ...exports.THEME_PRESETS[preset], displayMode: state.theme.displayMode };
        return state;
    });
}
async function setDisplayMode(modeValue) {
    const mode = String(modeValue ?? "");
    if (mode !== "auto" && mode !== "light" && mode !== "dark") {
        fail("INVALID_DISPLAY_MODE", "显示模式必须是 auto、light 或 dark");
    }
    return withLockedState(state => {
        state.theme.displayMode = mode;
        return state;
    });
}
async function setBackgroundImage(value) {
    const path = String(value ?? "").trim();
    if (path.length > 2000)
        fail("INVALID_BACKGROUND", "图片路径过长");
    return withLockedState(state => {
        state.backgroundImage = path;
        return state;
    });
}
async function setAppearanceOptions(opacityValue, frostedValue) {
    const opacity = Number(opacityValue);
    if (!Number.isFinite(opacity) || opacity < 0 || opacity > 1) {
        fail("INVALID_OPACITY", "图片透明度必须在 0% 到 100% 之间");
    }
    return withLockedState(state => {
        state.backgroundImageOpacity = opacity;
        state.frostedBubbles = frostedValue === true;
        return state;
    });
}
async function setCustomTheme(value) {
    const colors = [value.primary, value.background, value.surface, value.text];
    if (!colors.every(isHexColor))
        fail("INVALID_COLOR", "颜色必须使用 #RRGGBB 格式");
    return withLockedState(state => {
        state.theme = {
            preset: "custom",
            displayMode: state.theme.displayMode,
            primary: String(value.primary).toUpperCase(),
            background: String(value.background).toUpperCase(),
            surface: String(value.surface).toUpperCase(),
            text: String(value.text).toUpperCase()
        };
        return state;
    });
}
