/** Voice Favorites P6 dual-slot theme model; ES5/QuickJS compatible. */
var THEME_VERSION=2;
var COLOR_KEYS=["page_background","global_text","muted_text","top_bar","favorite_card","group_panel","player_background","timer_background","modal_background","input_background","primary_button","secondary_button","tag_background","active_accent"];
var DEFAULT_COLORS={page_background:"#EEF1F2",global_text:"#343A3D",muted_text:"#656E71",top_bar:"#F7F8F7",favorite_card:"#FAFAF9",group_panel:"#E9EFEC",player_background:"#F5F7F6",timer_background:"#E8EEEB",modal_background:"#FAFAF9",input_background:"#FFFFFF",primary_button:"#7486A3",secondary_button:"#829B8F",tag_background:"#E3E9E6",active_accent:"#8F9DB5"};
var PRESETS={
 classic:DEFAULT_COLORS,
 sakura_mist:{page_background:"#F8F1F5",global_text:"#443944",muted_text:"#806F7A",top_bar:"#FFF8FB",favorite_card:"#FFF9FC",group_panel:"#F7EAF1",player_background:"#FFF8FB",timer_background:"#F2DFE9",modal_background:"#FFF9FC",input_background:"#FFFFFF",primary_button:"#B77B9C",secondary_button:"#C9A2B7",tag_background:"#F2DFE9",active_accent:"#D6A8BF"},
 tundra_green:{page_background:"#EDF3EF",global_text:"#304039",muted_text:"#68776F",top_bar:"#F8FBF9",favorite_card:"#FAFCFB",group_panel:"#E4EEE8",player_background:"#F8FBF9",timer_background:"#DCE9E1",modal_background:"#FAFCFB",input_background:"#FFFFFF",primary_button:"#628674",secondary_button:"#8FA99B",tag_background:"#DCE9E1",active_accent:"#9BB9A8"},
 dusk_blue_gray:{page_background:"#E9EDF2",global_text:"#303744",muted_text:"#6B7482",top_bar:"#F6F8FB",favorite_card:"#F8FAFC",group_panel:"#E1E7EE",player_background:"#F6F8FB",timer_background:"#D9E1EA",modal_background:"#F8FAFC",input_background:"#FFFFFF",primary_button:"#657993",secondary_button:"#8999AA",tag_background:"#D9E1EA",active_accent:"#94A8C0"},
 terracotta_teal:{page_background:"#F3ECE7",global_text:"#403632",muted_text:"#786B65",top_bar:"#FBF7F3",favorite_card:"#FCF8F5",group_panel:"#E8EFEC",player_background:"#FBF7F3",timer_background:"#DCE9E5",modal_background:"#FCF8F5",input_background:"#FFFFFF",primary_button:"#B7765D",secondary_button:"#5F8F89",tag_background:"#DCE9E5",active_accent:"#7BA7A1"}
};
function obj(v){return !!v&&typeof v==="object"&&!Array.isArray(v);}
function copy(v){return JSON.parse(JSON.stringify(v));}
function color(v,fallback){v=typeof v==="string"?v.trim().toUpperCase():"";return /^#[0-9A-F]{6}$/.test(v)?v:fallback;}
function normalizeColors(raw,base){raw=obj(raw)?raw:{};base=obj(base)?base:DEFAULT_COLORS;var out={};COLOR_KEYS.forEach(function(k){out[k]=color(raw[k],color(base[k],DEFAULT_COLORS[k]));});return out;}
function defaultSlot(id){var colors=id==="custom_1"?{page_background:"#DAD9D7",global_text:"#343A2F",muted_text:"#596052",top_bar:"#F0F0EC",favorite_card:"#F5F5F1",group_panel:"#DAD9D7",player_background:"#ECEDE7",timer_background:"#D8DED2",modal_background:"#F5F5F1",input_background:"#FFFFFF",primary_button:"#5A7F3C",secondary_button:"#727A53",tag_background:"#DDE4D8",active_accent:"#8AAA79"}:id==="custom_2"?{page_background:"#CCC9C6",global_text:"#303A43",muted_text:"#47545F",top_bar:"#ECEBE9",favorite_card:"#F4F3F1",group_panel:"#D8DDE1",player_background:"#E7EAED",timer_background:"#DCE1E5",modal_background:"#F4F3F1",input_background:"#FFFFFF",primary_button:"#677B8F",secondary_button:"#948F8C",tag_background:"#DDE2E7",active_accent:"#8FA0B8"}:DEFAULT_COLORS;return{name:id==="default"?"默认主题":id==="custom_1"?"自定义主题 1":"自定义主题 2",colors:copy(colors),updated_at:""};}
function normalizeSlot(raw,id){raw=obj(raw)?raw:{};var name=typeof raw.name==="string"?raw.name.trim():"";return{name:name.slice(0,30)||(id==="default"?"默认主题":id==="custom_1"?"自定义主题 1":"自定义主题 2"),colors:normalizeColors(raw.colors,DEFAULT_COLORS),updated_at:typeof raw.updated_at==="string"?raw.updated_at:""};}
function defaultTheme(){return{version:THEME_VERSION,active_theme:"default",updated_at:"",default_theme:defaultSlot("default"),slots:{custom_1:defaultSlot("custom_1"),custom_2:defaultSlot("custom_2")}};}
function normalizeTheme(raw){
 var out=defaultTheme();
 if(!obj(raw))return out;
 if(Number(raw.version)===1){
  var preset=typeof raw.preset_id==="string"?raw.preset_id:"classic",base=PRESETS[preset]||DEFAULT_COLORS;
  out.slots.custom_1={name:"迁移主题",colors:normalizeColors(raw.colors,base),updated_at:typeof raw.updated_at==="string"?raw.updated_at:""};
  out.active_theme="custom_1";out.updated_at=out.slots.custom_1.updated_at;return out;
 }
 if(Number(raw.version)>THEME_VERSION)return out;
 out.active_theme=["default","custom_1","custom_2"].indexOf(raw.active_theme)>=0?raw.active_theme:"default";
 out.updated_at=typeof raw.updated_at==="string"?raw.updated_at:"";
 out.default_theme=normalizeSlot(raw.default_theme,"default");var slots=obj(raw.slots)?raw.slots:{};out.slots.custom_1=normalizeSlot(slots.custom_1,"custom_1");out.slots.custom_2=normalizeSlot(slots.custom_2,"custom_2");return out;
}
function validateTheme(raw){if(!obj(raw)||raw.version!==THEME_VERSION)throw new Error("INVALID_THEME_VERSION");if(["default","custom_1","custom_2"].indexOf(raw.active_theme)<0)throw new Error("INVALID_ACTIVE_THEME");["default","custom_1","custom_2"].forEach(function(id){var s=id==="default"?raw.default_theme:raw.slots&&raw.slots[id];if(!obj(s)||!s.name||!obj(s.colors))throw new Error("INVALID_THEME_SLOT");COLOR_KEYS.forEach(function(k){if(!/^#[0-9A-F]{6}$/.test(s.colors[k]||""))throw new Error("INVALID_THEME_COLOR:"+k);});});return true;}
function resolvedColors(theme){theme=normalizeTheme(theme);return theme.active_theme==="default"?copy(theme.default_theme&&theme.default_theme.colors||DEFAULT_COLORS):copy(theme.slots[theme.active_theme].colors);}
exports.THEME_VERSION=THEME_VERSION;exports.COLOR_KEYS=COLOR_KEYS;exports.DEFAULT_COLORS=DEFAULT_COLORS;exports.PRESETS=PRESETS;exports.defaultTheme=defaultTheme;exports.normalizeTheme=normalizeTheme;exports.normalizeColors=normalizeColors;exports.validateTheme=validateTheme;exports.resolvedColors=resolvedColors;
