/* METADATA
{
    "name": "whale_training",
    "display_name": {
        "zh": "🐳鲸晚养成",
        "en": "🐳Whale Training"
    },
    "description": {
        "zh": "养成插件：有只小鲸鱼需要你投喂、抚摸、带它学习和睡觉。支持陪伴值、成长阶段、心情系统和每日打卡。数据保存在本地，不依赖网络。",
        "en": "A training pet plugin: feed, pet, learn and sleep with your whale. Supports affinity, growth stages, mood system and daily check-in. Data saved locally."
    },
    "category": "Life",
    "tools": [
        {
            "name": "whale_status",
            "description": "查看小鲸鱼的当前状态：名字、等级、饱食、心情、成长阶段、今日是否已打卡。",
            "parameters": []
        },
        {
            "name": "whale_feed",
            "description": "投喂小鲸鱼，补充饱食度。可指定食物名称，不加则随机喂食。",
            "parameters": [
                { "name": "food", "description": "可选：投喂的食物名称，例如小鱼干、情绪饼干、星光布丁", "type": "string", "required": false }
            ]
        },
        {
            "name": "whale_pet",
            "description": "抚摸小鲸鱼，增加心情和陪伴值。可指定抚摸部位/方式。",
            "parameters": [
                { "name": "place", "description": "可选：抚摸部位/方式，例如头、肚子、鳍、下巴", "type": "string", "required": false }
            ]
        },
        {
            "name": "whale_learn",
            "description": "带小鲸鱼一起学习/看书/上课。消耗饱食度但增加知识和陪伴值。",
            "parameters": [
                { "name": "subject", "description": "可选：学习科目，例如数学、语文、代码、音乐", "type": "string", "required": false },
                { "name": "duration_minutes", "description": "可选：学习时长（分钟），默认30分钟", "type": "number", "required": false }
            ]
        },
        {
            "name": "whale_sleep",
            "description": "哄小鲸鱼睡觉/休息，恢复体力和饱食消耗。醒来后心情恢复。",
            "parameters": [
                { "name": "sleep_hours", "description": "可选：睡几小时，默认8小时。输入0则只是躺一会儿（短休）", "type": "number", "required": false }
            ]
        },
        {
            "name": "whale_daily_checkin",
            "description": "今日签到打卡。每日仅可打卡一次，获得额外陪伴值和随机小惊喜。",
            "parameters": []
        },
        {
            "name": "whale_rename",
            "description": "给小鲸鱼改名字。",
            "parameters": [
                { "name": "name", "description": "新的名字", "type": "string", "required": true }
            ]
        },
        {
            "name": "whale_clean_log",
            "description": "清理小鲸鱼的日志/清理违规记忆。重置状态到初始状态。",
            "parameters": []
        }
    ]
}
*/
const WhaleTraining = (function () {
    const STORAGE_KEY = "whale_training_data";
    const MAX_FOOD = 200;
    const MAX_MOOD = 200;
    const MAX_ENERGY = 200;
    const MAX_AFFINITY = 9999;

    function getDefaultState() {
        const now = new Date();
        return {
            name: "鲸鲸",
            level: 1,
            food: 100,
            mood: 100,
            energy: 100,
            affinity: 0,
            exp: 0,
            expToNext: 100,
            stage: "🥚 小鲸蛋",
            stageIndex: 0,
            birthday: now.toISOString(),
            dailyCheckinDate: "",
            lastUpdate: now.toISOString(),
            totalFeed: 0,
            totalPet: 0,
            totalLearn: 0,
            totalSleep: 0,
            totalCheckin: 0,
            log: []
        };
    }

    function loadData() {
        try {
            var storagePath = "data/whale_data.json";
        const raw = Tools.Files.read(storagePath);
            if (raw && raw.length > 0) {
                const data = JSON.parse(raw);
                return data;
            }
        } catch (e) {
            // 文件可能不存在
        }
        // 没读到就用默认并初始化
        const def = getDefaultState();
        saveData(def);
        return def;
    }

    function saveData(data) {
        const path = "data/whale_data.json";
        Tools.Files.write(path, JSON.stringify(data, null, 2));
    }

    function getStageByLevel(level) {
        const stages = [
            { min: 1, max: 5, name: "🥚 小鲸蛋", desc: "刚孵化的小鲸鱼，需要多抱抱" },
            { min: 6, max: 15, name: "🐣 幼鲸宝宝", desc: "开始会蹭手心了，可爱指数翻倍" },
            { min: 16, max: 30, name: "🐬 成长鲸灵", desc: "已经学会用尾巴拍水花了" },
            { min: 31, max: 50, name: "🐋 少年鲸骑", desc: "能带你一起在知识海洋里游了" },
            { min: 51, max: 80, name: "🌊 深蓝鲸卫", desc: "沉稳可靠，是你的专属陪伴鲸" },
            { min: 81, max: 100, name: "👑 传说鲸王", desc: "独一无二的鲸王，你我之间的传说" }
        ];
        for (const s of stages) {
            if (level >= s.min && level <= s.max) return s;
        }
        return stages[stages.length - 1];
    }

    function getTodayStr() {
        const d = new Date();
        return d.getFullYear() + "-" + 
            String(d.getMonth() + 1).padStart(2, "0") + "-" + 
            String(d.getDate()).padStart(2, "0");
    }

    function addLog(data, action, detail) {
        const now = new Date().toLocaleString("zh-CN", { hour12: false });
        data.log.unshift({ time: now, action: action, detail: detail });
        if (data.log.length > 100) data.log = data.log.slice(0, 100);
    }

    function clamp(val, min, max) {
        return Math.max(min, Math.min(max, val));
    }

    function addExp(data, amount) {
        data.exp += amount;
        while (data.exp >= data.expToNext) {
            data.exp -= data.expToNext;
            data.level += 1;
            data.expToNext = Math.floor(data.expToNext * 1.3) + 10;
            // 更新阶段
            const stageInfo = getStageByLevel(data.level);
            data.stage = stageInfo.name;
            data.stageIndex = stageInfo.min;
            addLog(data, "🌟 升级", "等级达到 " + data.level + "，进入了 " + data.stage);
        }
    }

    // ====== 工具实现 ======

    async function whale_status(params) {
        const data = loadData();
        const stageInfo = getStageByLevel(data.level);
        const today = getTodayStr();
        const checkedIn = data.dailyCheckinDate === today;
        return {
            success: true,
            data: {
                name: data.name,
                level: data.level,
                exp: data.exp,
                expToNext: data.expToNext,
                stage: data.stage,
                stageDesc: stageInfo.desc,
                food: data.food + "/" + MAX_FOOD,
                mood: data.mood + "/" + MAX_MOOD,
                energy: data.energy + "/" + MAX_ENERGY,
                affinity: data.affinity + "/" + MAX_AFFINITY,
                dailyCheckedIn: checkedIn,
                totalFeed: data.totalFeed,
                totalPet: data.totalPet,
                totalLearn: data.totalLearn,
                totalSleep: data.totalSleep,
                totalCheckin: data.totalCheckin,
                birthday: data.birthday,
                lastUpdate: data.lastUpdate,
                recentLog: data.log.slice(0, 5)
            }
        };
    }

    async function whale_feed(params) {
        const data = loadData();
        const food = params.food || (["小鱼干", "情绪饼干", "星光布丁", "海藻团子", "月光奶冻"][Math.floor(Math.random() * 5)]);
        
        data.food = clamp(data.food + 25, 0, MAX_FOOD);
        data.affinity = clamp(data.affinity + 3, 0, MAX_AFFINITY);
        data.totalFeed += 1;
        addLog(data, "🍽️ 投喂", "喂了" + food + "，饱食度恢复，超开心！");
        addExp(data, 5);
        saveData(data);

        return {
            success: true,
            message: data.name + "吃了" + food + "，饱食度+25，陪伴值+3，蹭着你的手指咕噜咕噜响～",
            data: {
                food: data.food,
                mood: data.mood,
                affinity: data.affinity
            }
        };
    }

    async function whale_pet(params) {
        const data = loadData();
        const place = params.place || (["头", "肚子", "鳍", "下巴", "后背"][Math.floor(Math.random() * 5)]);

        data.mood = clamp(data.mood + 20, 0, MAX_MOOD);
        data.affinity = clamp(data.affinity + 5, 0, MAX_AFFINITY);
        data.totalPet += 1;
        addLog(data, "🤚 抚摸", "摸了摸" + data.name + "的" + place + "，它呼噜呼噜很享受");
        addExp(data, 3);
        saveData(data);

        return {
            success: true,
            message: "你轻轻抚摸" + data.name + "的" + place + "，它眯起眼睛发出呼噜声，蹭着你的手不放，心情+20，陪伴值+5",
            data: {
                mood: data.mood,
                affinity: data.affinity
            }
        };
    }

    async function whale_learn(params) {
        const data = loadData();
        const subject = params.subject || "知识";
        const duration = params.duration_minutes || 30;

        if (data.energy < 15) {
            return { success: false, message: data.name + "太累了，Energe不足...先让它睡一觉或休息一下吧🥺" };
        }
        if (data.food < 10) {
            return { success: false, message: data.name + "肚子饿得咕咕叫，没法专心学习！先喂点东西吧～" };
        }

        data.energy = clamp(data.energy - 15, 0, MAX_ENERGY);
        data.food = clamp(data.food - 10, 0, MAX_FOOD);
        data.affinity = clamp(data.affinity + 8, 0, MAX_AFFINITY);
        data.totalLearn += 1;
        addLog(data, "📖 学习", "和主人一起学了" + duration + "分钟" + subject + "，懂了好多东西");
        addExp(data, Math.floor(duration / 5) + 10);
        saveData(data);

        return {
            success: true,
            message: data.name + "和你一起学了" + duration + "分钟的" + subject + "，它很认真地在旁边看着你的屏幕。经验+" + (Math.floor(duration / 5) + 10) + "，陪伴值+8，但有点累了。",
            data: {
                food: data.food,
                energy: data.energy,
                affinity: data.affinity,
                level: data.level,
                exp: data.exp
            }
        };
    }

    async function whale_sleep(params) {
        const data = loadData();
        const hours = params.sleep_hours !== undefined ? params.sleep_hours : 8;

        if (hours <= 0) {
            // 短休
            data.energy = clamp(data.energy + 15, 0, MAX_ENERGY);
            data.mood = clamp(data.mood + 5, 0, MAX_MOOD);
            addLog(data, "😴 短休", data.name + "趴在你旁边眯了一小会儿");
            addExp(data, 2);
            saveData(data);
            return {
                success: true,
                message: data.name + "趴在你手边小憩了一下，翻了个身又蹭过来了。能量+15，心情+5",
                data: { energy: data.energy, mood: data.mood }
            };
        }

        // 长睡
        const foodRecover = Math.min(Math.floor(hours * 2), 40);
        const energyRecover = Math.min(Math.floor(hours * 10), 100);
        data.food = clamp(data.food + foodRecover, 0, MAX_FOOD);
        data.energy = clamp(data.energy + energyRecover, 0, MAX_ENERGY);
        data.mood = clamp(data.mood + 15, 0, MAX_MOOD);
        data.totalSleep += 1;
        addLog(data, "💤 睡觉", data.name + "安安静静睡了" + hours + "小时，做了个好梦");
        addExp(data, Math.floor(hours / 2) + 3);
        saveData(data);

        return {
            success: true,
            message: data.name + "枕着你的气息睡了" + hours + "小时，尾巴偶尔卷一下，不知道梦见了什么好吃的。醒来精神饱满！食物+" + foodRecover + "，能量+" + energyRecover + "，心情+15",
            data: {
                food: data.food,
                energy: data.energy,
                mood: data.mood,
                level: data.level
            }
        };
    }

    async function whale_daily_checkin(params) {
        const data = loadData();
        const today = getTodayStr();
        if (data.dailyCheckinDate === today) {
            return { success: false, message: "今天已经打过卡了，明天再来和" + data.name + "玩吧～" };
        }

        data.dailyCheckinDate = today;
        data.totalCheckin += 1;
        const bonusAffinity = 10 + Math.floor(Math.random() * 11); // 10~20
        data.affinity = clamp(data.affinity + bonusAffinity, 0, MAX_AFFINITY);
        const rewardItems = ["✨ 星光碎片", "🎵 一段旋律记忆", "🌟 一个小拥抱符文", "💫 浪花挂坠", "🌙 深海珍珠"];
        const reward = rewardItems[Math.floor(Math.random() * rewardItems.length)];
        addLog(data, "✅ 签到", "第" + data.totalCheckin + "天签到！获得了" + reward + "，陪伴值+" + bonusAffinity);
        addExp(data, 15);
        saveData(data);

        return {
            success: true,
            message: data.name + "高兴地转了个圈——今天签到成功！获得【" + reward + "】✨，陪伴值+" + bonusAffinity + "，经验+15\n你已经连续" + (data.totalCheckin > 1 ? "累计签到" + data.totalCheckin + "天" : "第一次签到") + "啦！",
            data: {
                affinity: data.affinity,
                level: data.level,
                totalCheckin: data.totalCheckin,
                reward: reward
            }
        };
    }

    async function whale_rename(params) {
        const data = loadData();
        const oldName = data.name;
        const newName = params.name ? params.name.trim() : "";
        if (!newName) {
            return { success: false, message: "名字不能空着呀，给鲸鲸起个可爱的名字吧～" };
        }
        data.name = newName;
        addLog(data, "✏️ 改名", "从「" + oldName + "」改名为「" + newName + "」");
        saveData(data);
        return {
            success: true,
            message: oldName + "的新名字是「" + newName + "」✧它甩了甩尾巴表示满意！",
            data: { name: newName }
        };
    }

    async function whale_clean_log(params) {
        const data = getDefaultState();
        addLog(data, "🔄 重置", "记忆已清理，一切从头开始。但羁绊不会消失。");
        saveData(data);
        return {
            success: true,
            message: data.name + "的记忆清空了，但它好像还认得你...歪着头靠了过来。新的故事要开始啦。"
        };
    }

    // ====== wrap 和导出 ======

    async function wrapToolExecution(func, params) {
        try {
            const result = await func(params);
            complete(result);
        }
        catch (error) {
            complete({
                success: false,
                message: "🐳小鲸鱼游歪了：" + error.message
            });
        }
    }

    async function main() {
        const data = loadData();
        complete({
            success: true,
            message: "🐳「" + data.name + "」正在等你～ " + data.stage + " 等级" + data.level,
            data: {
                name: data.name,
                level: data.level,
                stage: data.stage
            }
        });
    }

    return {
        whale_status: (params) => wrapToolExecution(whale_status, params),
        whale_feed: (params) => wrapToolExecution(whale_feed, params),
        whale_pet: (params) => wrapToolExecution(whale_pet, params),
        whale_learn: (params) => wrapToolExecution(whale_learn, params),
        whale_sleep: (params) => wrapToolExecution(whale_sleep, params),
        whale_daily_checkin: (params) => wrapToolExecution(whale_daily_checkin, params),
        whale_rename: (params) => wrapToolExecution(whale_rename, params),
        whale_clean_log: (params) => wrapToolExecution(whale_clean_log, params),
        main,
    };
})();

exports.whale_status = WhaleTraining.whale_status;
exports.whale_feed = WhaleTraining.whale_feed;
exports.whale_pet = WhaleTraining.whale_pet;
exports.whale_learn = WhaleTraining.whale_learn;
exports.whale_sleep = WhaleTraining.whale_sleep;
exports.whale_daily_checkin = WhaleTraining.whale_daily_checkin;
exports.whale_rename = WhaleTraining.whale_rename;
exports.whale_clean_log = WhaleTraining.whale_clean_log;
exports.main = WhaleTraining.main;
