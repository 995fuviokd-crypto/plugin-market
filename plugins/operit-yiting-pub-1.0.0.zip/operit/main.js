// 一起听 · Listen Together — RikkaHub 适配版
// 工具：reply_in_hut（AI 在小屋聊天气泡中回复）
// 数据与面板共用沙箱 yiting/ 目录（chatlog.json 等）
"use strict";

async function __yitSafeRead() {
  try {
    const r = await Tools.Files.read({ path: "yiting/chatlog.json", environment: "sandbox" });
    if (!r || !r.content) return [];
    const j = JSON.parse(String(r.content));
    return Array.isArray(j) ? j : [];
  } catch (e) { return []; }
}

async function __yitSafeWrite(list) {
  try {
    await Tools.Files.write("yiting/chatlog.json", JSON.stringify(list), false, "sandbox");
    return true;
  } catch (e) { return false; }
}

async function reply_in_hut(args) {
  const text = String((args && args.text) || "").trim();
  if (!text) return { success: false, message: "空回复" };
  try {
    const list = await __yitSafeRead();
    list.push({ role: "ai", text: text, ts: Date.now() });
    const ok = await __yitSafeWrite(list);
    return ok ? { success: true, message: "已回复到小屋" } : { success: false, message: "回复失败：数据写入被拒绝" };
  } catch (e) {
    return { success: false, message: String(e && e.message || e) };
  }
}

module.exports = {
  reply_in_hut: reply_in_hut,
  "yiting:reply_in_hut": reply_in_hut,
};
