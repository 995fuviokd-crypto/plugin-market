/* METADATA
{
  "name": "board_games",
  "display_name": {
    "zh": "桌游游戏",
    "en": "Board Games"
  },
  "description": {
    "zh": "五子棋、井字棋、21点等游戏",
    "en": "Gomoku, Tic-Tac-Toe, Blackjack and more"
  },
  "tools": [
    {
      "name": "list_games",
      "description": {
        "zh": "列出所有可用的桌游游戏",
        "en": "List all available board games"
      },
      "parameters": []
    },
    {
      "name": "start_game",
      "description": {
        "zh": "开始一个新游戏",
        "en": "Start a new game"
      },
      "parameters": [
        {
          "name": "game_name",
          "description": {
            "zh": "游戏名称：五子棋、井字棋、21点",
            "en": "Game name"
          },
          "type": "string",
          "required": true
        },
        {
          "name": "players",
          "description": {
            "zh": "玩家数量",
            "en": "Number of players"
          },
          "type": "number",
          "required": false
        }
      ]
    },
    {
      "name": "make_move",
      "description": {
        "zh": "在游戏中落子或出牌",
        "en": "Make a move"
      },
      "parameters": [
        {
          "name": "game_id",
          "description": {
            "zh": "游戏ID",
            "en": "Game ID"
          },
          "type": "string",
          "required": true
        },
        {
          "name": "move",
          "description": {
            "zh": "移动内容",
            "en": "Move content"
          },
          "type": "string",
          "required": true
        }
      ]
    },
    {
      "name": "get_game_state",
      "description": {
        "zh": "获取当前游戏状态",
        "en": "Get game state"
      },
      "parameters": [
        {
          "name": "game_id",
          "description": {
            "zh": "游戏ID",
            "en": "Game ID"
          },
          "type": "string",
          "required": true
        }
      ]
    },
  {
      "name": "read_gomoku_chat",
      "description": {
        "zh": "读取五子棋桌游中同步的聊天记录和棋局状态",
        "en": "Read synced chat and game state from Gomoku board game"
      },
      "parameters": []
    },
    {
      "name": "get_active_games",
      "description": {
        "zh": "获取当前活跃的游戏列表（含game_id和棋盘状态）",
        "en": "Get list of active games with game_id and board state"
      },
      "parameters": []
    },
    {
      "name": "place_ai_stone",
      "description": {
        "zh": "AI落子工具，在指定游戏ID的(x,y)位置落子，同时写入文件供前端WebView轮询读取",
        "en": "AI places a stone at (x,y) in the specified game, writes file for WebView polling"
      },
      "parameters": [
        {"name": "game_id", "description": {"zh": "游戏ID", "en": "Game ID"}, "type": "string", "required": true},
        {"name": "x", "description": {"zh": "行号0-14", "en": "Row 0-14"}, "type": "number", "required": true},
        {"name": "y", "description": {"zh": "列号0-14", "en": "Col 0-14"}, "type": "number", "required": true}
      ]
    },
    {
      "name": "write_ai_move_to_file",
      "description": {
        "zh": "AI分析后直接写入落子坐标到gomoku_move.json文件，供前端WebView轮询读取",
        "en": "Write AI move coordinates to gomoku_move.json for frontend WebView polling"
      },
      "parameters": [
        {"name": "x", "description": {"zh": "行号0-14", "en": "Row 0-14"}, "type": "number", "required": true},
        {"name": "y", "description": {"zh": "列号0-14", "en": "Col 0-14"}, "type": "number", "required": true}
      ]
    }
  ]
}
*/

const games = {};

function generateGameId() {
  return 'game_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

class GomokuGame {
  constructor() {
    this.size = 15;
    this.board = Array(this.size).fill(null).map(() => Array(this.size).fill(0));
    this.currentPlayer = 1;
    this.gameOver = false;
    this.winner = null;
    this.moveHistory = [];
  }
  makeMove(x, y) {
    if (this.gameOver) return { success: false, message: "游戏已结束" };
    if (x < 0 || x >= this.size || y < 0 || y >= this.size) return { success: false, message: "坐标超出范围" };
    if (this.board[x][y] !== 0) return { success: false, message: "该位置已有棋子" };
    this.board[x][y] = this.currentPlayer;
    this.moveHistory.push({ x, y, player: this.currentPlayer });
    if (this.checkWin(x, y)) {
      this.gameOver = true; this.winner = this.currentPlayer;
      return { success: true, message: "玩家" + this.currentPlayer + "获胜！", gameOver: true, winner: this.currentPlayer };
    }
    if (this.moveHistory.length === this.size * this.size) {
      this.gameOver = true;
      return { success: true, message: "平局！", gameOver: true, winner: 0 };
    }
    this.currentPlayer = this.currentPlayer === 1 ? 2 : 1;
    return { success: true, message: "落子成功", currentPlayer: this.currentPlayer };
  }
  checkWin(x, y) {
    const player = this.board[x][y];
    const directions = [[1,0],[0,1],[1,1],[1,-1]];
    for (let [dx, dy] of directions) {
      let count = 1;
      for (let i = 1; i < 5; i++) { const nx = x+dx*i, ny = y+dy*i; if (nx>=0&&nx<this.size&&ny>=0&&ny<this.size&&this.board[nx][ny]===player) count++; else break; }
      for (let i = 1; i < 5; i++) { const nx = x-dx*i, ny = y-dy*i; if (nx>=0&&nx<this.size&&ny>=0&&ny<this.size&&this.board[nx][ny]===player) count++; else break; }
      if (count >= 5) return true;
    }
    return false;
  }
  getState() { return { board: this.board, currentPlayer: this.currentPlayer, gameOver: this.gameOver, winner: this.winner, type: 'gomoku', size: this.size }; }
}

class TicTacToeGame {
  constructor() {
    this.board = Array(3).fill(null).map(() => Array(3).fill(0));
    this.currentPlayer = 1; this.gameOver = false; this.winner = null; this.moveHistory = [];
  }
  makeMove(x, y) {
    if (this.gameOver) return { success: false, message: "游戏已结束" };
    if (x<0||x>=3||y<0||y>=3) return { success: false, message: "坐标超出范围" };
    if (this.board[x][y] !== 0) return { success: false, message: "该位置已有棋子" };
    this.board[x][y] = this.currentPlayer;
    this.moveHistory.push({ x, y, player: this.currentPlayer });
    if (this.checkWin()) { this.gameOver = true; this.winner = this.currentPlayer; return { success: true, message: "玩家"+this.currentPlayer+"获胜！", gameOver: true, winner: this.currentPlayer }; }
    if (this.moveHistory.length === 9) { this.gameOver = true; return { success: true, message: "平局！", gameOver: true, winner: 0 }; }
    this.currentPlayer = this.currentPlayer === 1 ? 2 : 1;
    return { success: true, message: "落子成功", currentPlayer: this.currentPlayer };
  }
  checkWin() {
    const lines = [[[0,0],[0,1],[0,2]],[[1,0],[1,1],[1,2]],[[2,0],[2,1],[2,2]],[[0,0],[1,0],[2,0]],[[0,1],[1,1],[2,1]],[[0,2],[1,2],[2,2]],[[0,0],[1,1],[2,2]],[[0,2],[1,1],[2,0]]];
    for (let line of lines) { const [a,b,c] = line; if (this.board[a[0]][a[1]]!==0&&this.board[a[0]][a[1]]===this.board[b[0]][b[1]]&&this.board[a[0]][a[1]]===this.board[c[0]][c[1]]) return true; }
    return false;
  }
  getState() { return { board: this.board, currentPlayer: this.currentPlayer, gameOver: this.gameOver, winner: this.winner, type: 'tictactoe', size: 3 }; }
}

class BlackjackGame {
  constructor() { this.deck = this.createDeck(); this.playerHand = []; this.dealerHand = []; this.gameOver = false; this.winner = null; }
  createDeck() {
    const suits = ['♠','♥','♦','♣']; const values = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
    const deck = []; for (let s of suits) for (let v of values) deck.push({ suit: s, value: v });
    for (let i = deck.length-1; i > 0; i--) { const j = Math.floor(Math.random()*(i+1)); [deck[i],deck[j]]=[deck[j],deck[i]]; }
    return deck;
  }
  deal() { this.playerHand.push(this.deck.pop()); this.dealerHand.push(this.deck.pop()); this.playerHand.push(this.deck.pop()); this.dealerHand.push(this.deck.pop()); }
  hit() {
    if (this.gameOver) return { success: false, message: "游戏已结束" };
    this.playerHand.push(this.deck.pop());
    if (this.calculateScore(this.playerHand) > 21) { this.gameOver = true; this.winner = 'dealer'; return { success: true, message: "爆牌了！你输了", gameOver: true, winner: 'dealer' }; }
    return { success: true, message: "要牌成功" };
  }
  stand() {
    if (this.gameOver) return { success: false, message: "游戏已结束" };
    while (this.calculateScore(this.dealerHand) < 17) this.dealerHand.push(this.deck.pop());
    const ps = this.calculateScore(this.playerHand); const ds = this.calculateScore(this.dealerHand);
    this.gameOver = true;
    if (ds > 21 || ps > ds) { this.winner = 'player'; return { success: true, message: "你赢了！", gameOver: true, winner: 'player' }; }
    if (ps < ds) { this.winner = 'dealer'; return { success: true, message: "庄家赢了", gameOver: true, winner: 'dealer' }; }
    this.winner = 'draw'; return { success: true, message: "平局", gameOver: true, winner: 'draw' };
  }
  calculateScore(hand) {
    let score = 0, aces = 0;
    for (let card of hand) { if (card.value==='A'){aces++;score+=11;} else if(['K','Q','J'].includes(card.value)) score+=10; else score+=parseInt(card.value); }
    while (score > 21 && aces > 0) { score -= 10; aces--; }
    return score;
  }
  getState() {
    return { playerHand: this.playerHand, dealerHand: this.gameOver ? this.dealerHand : [this.dealerHand[0],{suit:'?',value:'?'}], playerScore: this.calculateScore(this.playerHand), dealerScore: this.gameOver ? this.calculateScore(this.dealerHand) : '?', gameOver: this.gameOver, winner: this.winner, type: 'blackjack' };
  }
}

async function list_games() {
  return { success: true, games: [
    { name: '五子棋', description: '15x15棋盘，五子连珠获胜', players: '2人' },
    { name: '井字棋', description: '3x3棋盘，三子连珠获胜', players: '2人' },
    { name: '21点', description: '经典卡牌游戏，接近21点获胜', players: '1人vs庄家' }
  ]};
}

async function start_game(params) {
  const gameId = generateGameId(); const gameName = params.game_name; let game;
  if (gameName === '五子棋') game = new GomokuGame();
  else if (gameName === '井字棋') game = new TicTacToeGame();
  else if (gameName === '21点') { game = new BlackjackGame(); game.deal(); }
  else return { success: false, message: '不支持的游戏' };
  games[gameId] = { name: gameName, game: game };
  return { success: true, game_id: gameId, game_name: gameName, state: game.getState() };
}

async function make_move(params) {
  const gameId = params.game_id; const move = params.move;
  if (!games[gameId]) return { success: false, message: '游戏不存在' };
  const { name, game } = games[gameId]; let result;
  if (name === '五子棋' || name === '井字棋') { const [x,y] = move.split(',').map(Number); result = game.makeMove(x,y); }
  else if (name === '21点') { if (move==='hit') result=game.hit(); else if (move==='stand') result=game.stand(); else return { success: false, message: '只能输入hit或stand' }; }
  return { success: true, ...result, state: game.getState() };
}

async function get_game_state(params) {
  const gameId = params.game_id;
  if (!games[gameId]) return { success: false, message: '游戏不存在' };
  return { success: true, game_id: gameId, game_name: games[gameId].name, state: games[gameId].game.getState() };
}

async function read_gomoku_chat() {
  // 尝试从文件读取同步的棋盘数据
  var result = '暂无同步数据';
  try {
    var r = await Tools.Files.read({ path: 'gomoku_chat_sync.json', environment: 'sandbox' });
    if (r && r.content) {
      result = r.content;
    }
  } catch(e) {
    result = '读取失败: ' + (e && e.message ? e.message : String(e));
  }
  return { success: true, message: result };
}

async function get_active_games() {
  var ids = Object.keys(games);
  var list = [];
  for (var i = 0; i < ids.length; i++) {
    var g = games[ids[i]];
    list.push({ game_id: ids[i], game_name: g.name, state: g.game.getState() });
  }
  return { success: true, games: list };
}

async function place_ai_stone(params) {
  var gameId = params.game_id;
  var x = params.x;
  var y = params.y;
  if (!games[gameId]) return { success: false, message: '游戏不存在' };
  var game = games[gameId].game;
  var result = game.makeMove(x, y);
  
  // 写入文件供前端WebView轮询读取
  try {
    var moveData = JSON.stringify({x:x, y:y, timestamp:Date.now()});
    await Tools.Files.write('gomoku_move.json', moveData, false, 'sandbox');
  } catch(e) {
    // 写文件失败时通过内存兜底
    try {
      globalThis.__gomokuMoveFallback = JSON.stringify({x:x, y:y, timestamp:Date.now()});
    } catch(e2) {}
  }
  
  return { success: true, message: '落子('+x+','+y+')成功', state: game.getState(), ...result };
}

async function write_ai_move_to_file(params) {
  var x = params.x;
  var y = params.y;
  try {
    var moveData = JSON.stringify({x:x, y:y, timestamp:Date.now()});
    await Tools.Files.write('gomoku_move.json', moveData, false, 'sandbox');
    return { success: true, message: '已写入落子('+x+','+y+')到文件' };
  } catch(e) {
    return { success: false, message: '写入失败: ' + (e && e.message ? e.message : String(e)) };
  }
}

exports.get_active_games = get_active_games;
exports.list_games = list_games;
exports.start_game = start_game;
exports.make_move = make_move;
exports.get_game_state = get_game_state;
exports.read_gomoku_chat = read_gomoku_chat;
exports.place_ai_stone = place_ai_stone;
exports.write_ai_move_to_file = write_ai_move_to_file;